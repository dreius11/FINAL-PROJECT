﻿using FINAL_PROJECT.User_Control;

namespace FINAL_PROJECT
{
    partial class ADMIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADMIN));
            panel3 = new Panel();
            button1 = new Button();
            labelUsername = new Label();
            panel4 = new Panel();
            labelDateTime = new Label();
            linkLabelLogout = new LinkLabel();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            panel11 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            btnguest = new Button();
            buttonreservation = new Button();
            buttonroom = new Button();
            buttonemployee = new Button();
            buttonrevenue = new Button();
            btndashboard = new Button();
            panelSlide = new Panel();
            panel1 = new Panel();
            btnsuggest = new Button();
            btnaccount = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            panel5 = new Panel();
            suggestionview1 = new suggestionview();
            revenue1 = new revenue();
            checkInView1 = new CheckInView();
            accountuser2 = new accountuser();
            roomStatus2 = new RoomStatus();
            roomStatus1 = new RoomStatus();
            employeeUser2 = new EmployeeUser();
            employeeUser1 = new EmployeeUser();
            dashboarduser4 = new dashboarduser();
            reservationuser1 = new reservationuser();
            dashboarduser3 = new dashboarduser();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.Teal;
            panel3.Controls.Add(button1);
            panel3.Controls.Add(labelUsername);
            panel3.Controls.Add(panel4);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(222, 0);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(1035, 193);
            panel3.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.Transparent;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(936, 133);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(86, 31);
            button1.TabIndex = 1;
            button1.Text = "REFRESH";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // labelUsername
            // 
            labelUsername.AutoSize = true;
            labelUsername.BackColor = Color.Transparent;
            labelUsername.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold);
            labelUsername.ForeColor = Color.White;
            labelUsername.Location = new Point(6, 133);
            labelUsername.Name = "labelUsername";
            labelUsername.Size = new Size(29, 37);
            labelUsername.TabIndex = 1;
            labelUsername.Text = "?";
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(labelDateTime);
            panel4.Controls.Add(linkLabelLogout);
            panel4.Controls.Add(pictureBox2);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(1035, 88);
            panel4.TabIndex = 0;
            // 
            // labelDateTime
            // 
            labelDateTime.AutoSize = true;
            labelDateTime.BackColor = Color.Transparent;
            labelDateTime.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelDateTime.ForeColor = Color.Teal;
            labelDateTime.Location = new Point(0, 60);
            labelDateTime.Name = "labelDateTime";
            labelDateTime.Size = new Size(21, 28);
            labelDateTime.TabIndex = 0;
            labelDateTime.Text = "?";
            // 
            // linkLabelLogout
            // 
            linkLabelLogout.AutoSize = true;
            linkLabelLogout.DisabledLinkColor = Color.Teal;
            linkLabelLogout.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabelLogout.LinkColor = Color.Teal;
            linkLabelLogout.Location = new Point(946, 39);
            linkLabelLogout.Name = "linkLabelLogout";
            linkLabelLogout.Size = new Size(83, 28);
            linkLabelLogout.TabIndex = 0;
            linkLabelLogout.TabStop = true;
            linkLabelLogout.Text = "Log Out";
            linkLabelLogout.LinkClicked += linkLabelLogout_LinkClicked;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.BackgroundImageLayout = ImageLayout.None;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(896, 27);
            pictureBox2.Margin = new Padding(3, 4, 3, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(43, 51);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackgroundImageLayout = ImageLayout.None;
            panel2.Controls.Add(panel11);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(label3);
            panel2.Dock = DockStyle.Top;
            panel2.ForeColor = SystemColors.ControlLightLight;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(222, 197);
            panel2.TabIndex = 0;
            // 
            // panel11
            // 
            panel11.BackColor = Color.White;
            panel11.Dock = DockStyle.Bottom;
            panel11.Location = new Point(0, 193);
            panel11.Margin = new Padding(3, 4, 3, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(222, 4);
            panel11.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(62, 141);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(80, 28);
            label1.TabIndex = 56;
            label1.Text = "System";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(78, 27);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 64);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 55;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(11, 108);
            label3.Margin = new Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new Size(195, 28);
            label3.TabIndex = 54;
            label3.Text = "Hotel Management";
            // 
            // btnguest
            // 
            btnguest.Anchor = AnchorStyles.None;
            btnguest.BackColor = Color.Teal;
            btnguest.BackgroundImageLayout = ImageLayout.None;
            btnguest.Cursor = Cursors.Hand;
            btnguest.FlatAppearance.BorderSize = 0;
            btnguest.FlatStyle = FlatStyle.Flat;
            btnguest.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnguest.ForeColor = Color.White;
            btnguest.Image = (Image)resources.GetObject("btnguest.Image");
            btnguest.ImageAlign = ContentAlignment.MiddleLeft;
            btnguest.Location = new Point(26, 455);
            btnguest.Margin = new Padding(5, 5, 5, 5);
            btnguest.Name = "btnguest";
            btnguest.RightToLeft = RightToLeft.No;
            btnguest.Size = new Size(190, 52);
            btnguest.TabIndex = 3;
            btnguest.Text = "  Guest";
            btnguest.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnguest.UseVisualStyleBackColor = false;
            btnguest.Click += btnguest_Click;
            // 
            // buttonreservation
            // 
            buttonreservation.Anchor = AnchorStyles.None;
            buttonreservation.BackColor = Color.Teal;
            buttonreservation.BackgroundImageLayout = ImageLayout.None;
            buttonreservation.Cursor = Cursors.Hand;
            buttonreservation.FlatAppearance.BorderSize = 0;
            buttonreservation.FlatStyle = FlatStyle.Flat;
            buttonreservation.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonreservation.ForeColor = Color.White;
            buttonreservation.Image = (Image)resources.GetObject("buttonreservation.Image");
            buttonreservation.ImageAlign = ContentAlignment.MiddleLeft;
            buttonreservation.Location = new Point(26, 392);
            buttonreservation.Margin = new Padding(5, 5, 5, 5);
            buttonreservation.Name = "buttonreservation";
            buttonreservation.Size = new Size(190, 52);
            buttonreservation.TabIndex = 2;
            buttonreservation.Text = "  Reservation";
            buttonreservation.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonreservation.UseVisualStyleBackColor = false;
            buttonreservation.Click += buttonreservation_Click;
            // 
            // buttonroom
            // 
            buttonroom.Anchor = AnchorStyles.None;
            buttonroom.BackColor = Color.Teal;
            buttonroom.BackgroundImageLayout = ImageLayout.None;
            buttonroom.Cursor = Cursors.Hand;
            buttonroom.FlatAppearance.BorderSize = 0;
            buttonroom.FlatStyle = FlatStyle.Flat;
            buttonroom.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonroom.ForeColor = Color.White;
            buttonroom.Image = (Image)resources.GetObject("buttonroom.Image");
            buttonroom.ImageAlign = ContentAlignment.MiddleLeft;
            buttonroom.Location = new Point(26, 517);
            buttonroom.Margin = new Padding(5, 5, 5, 5);
            buttonroom.Name = "buttonroom";
            buttonroom.Size = new Size(190, 52);
            buttonroom.TabIndex = 4;
            buttonroom.Text = "  Room";
            buttonroom.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonroom.UseVisualStyleBackColor = false;
            buttonroom.Click += buttonroom_Click;
            // 
            // buttonemployee
            // 
            buttonemployee.Anchor = AnchorStyles.None;
            buttonemployee.BackColor = Color.Teal;
            buttonemployee.BackgroundImageLayout = ImageLayout.None;
            buttonemployee.Cursor = Cursors.Hand;
            buttonemployee.FlatAppearance.BorderSize = 0;
            buttonemployee.FlatStyle = FlatStyle.Flat;
            buttonemployee.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonemployee.ForeColor = Color.White;
            buttonemployee.Image = (Image)resources.GetObject("buttonemployee.Image");
            buttonemployee.ImageAlign = ContentAlignment.MiddleLeft;
            buttonemployee.Location = new Point(26, 580);
            buttonemployee.Margin = new Padding(5, 5, 5, 5);
            buttonemployee.Name = "buttonemployee";
            buttonemployee.Size = new Size(190, 52);
            buttonemployee.TabIndex = 5;
            buttonemployee.Text = "Employee";
            buttonemployee.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonemployee.UseVisualStyleBackColor = false;
            buttonemployee.Click += buttonemployee_Click;
            // 
            // buttonrevenue
            // 
            buttonrevenue.Anchor = AnchorStyles.None;
            buttonrevenue.BackColor = Color.Teal;
            buttonrevenue.BackgroundImageLayout = ImageLayout.None;
            buttonrevenue.Cursor = Cursors.Hand;
            buttonrevenue.FlatAppearance.BorderSize = 0;
            buttonrevenue.FlatStyle = FlatStyle.Flat;
            buttonrevenue.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonrevenue.ForeColor = Color.White;
            buttonrevenue.Image = (Image)resources.GetObject("buttonrevenue.Image");
            buttonrevenue.ImageAlign = ContentAlignment.MiddleLeft;
            buttonrevenue.Location = new Point(26, 705);
            buttonrevenue.Margin = new Padding(5, 5, 5, 5);
            buttonrevenue.Name = "buttonrevenue";
            buttonrevenue.Size = new Size(190, 52);
            buttonrevenue.TabIndex = 6;
            buttonrevenue.Text = "Analytics";
            buttonrevenue.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonrevenue.UseVisualStyleBackColor = false;
            buttonrevenue.Click += buttonrevenue_Click;
            // 
            // btndashboard
            // 
            btndashboard.Anchor = AnchorStyles.None;
            btndashboard.BackColor = Color.Teal;
            btndashboard.BackgroundImageLayout = ImageLayout.None;
            btndashboard.Cursor = Cursors.Hand;
            btndashboard.FlatAppearance.BorderSize = 0;
            btndashboard.FlatStyle = FlatStyle.Flat;
            btndashboard.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btndashboard.ForeColor = Color.White;
            btndashboard.Image = (Image)resources.GetObject("btndashboard.Image");
            btndashboard.ImageAlign = ContentAlignment.MiddleLeft;
            btndashboard.Location = new Point(26, 329);
            btndashboard.Margin = new Padding(5, 5, 5, 5);
            btndashboard.Name = "btndashboard";
            btndashboard.Size = new Size(190, 52);
            btndashboard.TabIndex = 1;
            btndashboard.Text = "  Dashboard";
            btndashboard.TextImageRelation = TextImageRelation.ImageBeforeText;
            btndashboard.UseVisualStyleBackColor = false;
            btndashboard.Click += btndashboard_Click;
            // 
            // panelSlide
            // 
            panelSlide.BackColor = Color.White;
            panelSlide.Location = new Point(14, 329);
            panelSlide.Margin = new Padding(3, 4, 3, 4);
            panelSlide.Name = "panelSlide";
            panelSlide.Size = new Size(6, 52);
            panelSlide.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Teal;
            panel1.BackgroundImageLayout = ImageLayout.Stretch;
            panel1.Controls.Add(btnsuggest);
            panel1.Controls.Add(btnaccount);
            panel1.Controls.Add(panelSlide);
            panel1.Controls.Add(btndashboard);
            panel1.Controls.Add(buttonrevenue);
            panel1.Controls.Add(buttonemployee);
            panel1.Controls.Add(buttonroom);
            panel1.Controls.Add(buttonreservation);
            panel1.Controls.Add(btnguest);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(222, 1000);
            panel1.TabIndex = 0;
            // 
            // btnsuggest
            // 
            btnsuggest.Anchor = AnchorStyles.None;
            btnsuggest.BackColor = Color.Teal;
            btnsuggest.BackgroundImageLayout = ImageLayout.None;
            btnsuggest.Cursor = Cursors.Hand;
            btnsuggest.FlatAppearance.BorderSize = 0;
            btnsuggest.FlatStyle = FlatStyle.Flat;
            btnsuggest.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsuggest.ForeColor = Color.White;
            btnsuggest.Image = (Image)resources.GetObject("btnsuggest.Image");
            btnsuggest.ImageAlign = ContentAlignment.MiddleLeft;
            btnsuggest.Location = new Point(24, 768);
            btnsuggest.Margin = new Padding(5, 5, 5, 5);
            btnsuggest.Name = "btnsuggest";
            btnsuggest.Size = new Size(190, 52);
            btnsuggest.TabIndex = 9;
            btnsuggest.Text = "Suggetions";
            btnsuggest.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnsuggest.UseVisualStyleBackColor = false;
            btnsuggest.Click += btnsuggest_Click;
            // 
            // btnaccount
            // 
            btnaccount.Anchor = AnchorStyles.None;
            btnaccount.BackColor = Color.Teal;
            btnaccount.BackgroundImageLayout = ImageLayout.None;
            btnaccount.Cursor = Cursors.Hand;
            btnaccount.FlatAppearance.BorderSize = 0;
            btnaccount.FlatStyle = FlatStyle.Flat;
            btnaccount.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnaccount.ForeColor = Color.White;
            btnaccount.Image = (Image)resources.GetObject("btnaccount.Image");
            btnaccount.ImageAlign = ContentAlignment.MiddleLeft;
            btnaccount.Location = new Point(26, 643);
            btnaccount.Margin = new Padding(5, 5, 5, 5);
            btnaccount.Name = "btnaccount";
            btnaccount.Size = new Size(190, 52);
            btnaccount.TabIndex = 7;
            btnaccount.Text = "Account";
            btnaccount.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnaccount.UseVisualStyleBackColor = false;
            btnaccount.Click += btnaccount_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // panel5
            // 
            panel5.Controls.Add(suggestionview1);
            panel5.Controls.Add(revenue1);
            panel5.Controls.Add(checkInView1);
            panel5.Controls.Add(accountuser2);
            panel5.Controls.Add(roomStatus2);
            panel5.Controls.Add(roomStatus1);
            panel5.Controls.Add(employeeUser2);
            panel5.Controls.Add(employeeUser1);
            panel5.Controls.Add(dashboarduser4);
            panel5.Controls.Add(reservationuser1);
            panel5.Controls.Add(dashboarduser3);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(222, 193);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(1035, 807);
            panel5.TabIndex = 1;
            // 
            // suggestionview1
            // 
            suggestionview1.BackColor = Color.White;
            suggestionview1.Dock = DockStyle.Fill;
            suggestionview1.Location = new Point(0, 0);
            suggestionview1.Margin = new Padding(3, 5, 3, 5);
            suggestionview1.Name = "suggestionview1";
            suggestionview1.Size = new Size(1035, 807);
            suggestionview1.TabIndex = 11;
            // 
            // revenue1
            // 
            revenue1.Dock = DockStyle.Fill;
            revenue1.Location = new Point(0, 0);
            revenue1.Margin = new Padding(3, 5, 3, 5);
            revenue1.Name = "revenue1";
            revenue1.Size = new Size(1035, 807);
            revenue1.TabIndex = 10;
            // 
            // checkInView1
            // 
            checkInView1.Dock = DockStyle.Fill;
            checkInView1.Location = new Point(0, 0);
            checkInView1.Margin = new Padding(3, 5, 3, 5);
            checkInView1.Name = "checkInView1";
            checkInView1.Size = new Size(1035, 807);
            checkInView1.TabIndex = 9;
            // 
            // accountuser2
            // 
            accountuser2.Dock = DockStyle.Fill;
            accountuser2.Location = new Point(0, 0);
            accountuser2.Margin = new Padding(3, 5, 3, 5);
            accountuser2.Name = "accountuser2";
            accountuser2.Size = new Size(1035, 807);
            accountuser2.TabIndex = 8;
            // 
            // roomStatus2
            // 
            roomStatus2.Dock = DockStyle.Fill;
            roomStatus2.Location = new Point(0, 0);
            roomStatus2.Margin = new Padding(3, 5, 3, 5);
            roomStatus2.Name = "roomStatus2";
            roomStatus2.Size = new Size(1035, 807);
            roomStatus2.TabIndex = 7;
            // 
            // roomStatus1
            // 
            roomStatus1.Dock = DockStyle.Fill;
            roomStatus1.Location = new Point(0, 0);
            roomStatus1.Margin = new Padding(3, 5, 3, 5);
            roomStatus1.Name = "roomStatus1";
            roomStatus1.Size = new Size(1035, 807);
            roomStatus1.TabIndex = 6;
            // 
            // employeeUser2
            // 
            employeeUser2.Dock = DockStyle.Fill;
            employeeUser2.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            employeeUser2.Location = new Point(0, 0);
            employeeUser2.Margin = new Padding(5, 5, 5, 5);
            employeeUser2.Name = "employeeUser2";
            employeeUser2.Size = new Size(1035, 807);
            employeeUser2.TabIndex = 5;
            // 
            // employeeUser1
            // 
            employeeUser1.Dock = DockStyle.Fill;
            employeeUser1.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            employeeUser1.Location = new Point(0, 0);
            employeeUser1.Margin = new Padding(5, 5, 5, 5);
            employeeUser1.Name = "employeeUser1";
            employeeUser1.Size = new Size(1035, 807);
            employeeUser1.TabIndex = 4;
            // 
            // dashboarduser4
            // 
            dashboarduser4.BackColor = Color.White;
            dashboarduser4.Dock = DockStyle.Fill;
            dashboarduser4.Location = new Point(0, 0);
            dashboarduser4.Margin = new Padding(3, 5, 3, 5);
            dashboarduser4.Name = "dashboarduser4";
            dashboarduser4.Size = new Size(1035, 807);
            dashboarduser4.TabIndex = 2;
            // 
            // reservationuser1
            // 
            reservationuser1.Dock = DockStyle.Fill;
            reservationuser1.Location = new Point(0, 0);
            reservationuser1.Margin = new Padding(3, 5, 3, 5);
            reservationuser1.Name = "reservationuser1";
            reservationuser1.Size = new Size(1035, 807);
            reservationuser1.TabIndex = 1;
            // 
            // dashboarduser3
            // 
            dashboarduser3.BackColor = Color.White;
            dashboarduser3.Dock = DockStyle.Fill;
            dashboarduser3.Location = new Point(0, 0);
            dashboarduser3.Margin = new Padding(3, 5, 3, 5);
            dashboarduser3.Name = "dashboarduser3";
            dashboarduser3.Size = new Size(1035, 807);
            dashboarduser3.TabIndex = 0;
            // 
            // ADMIN
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1257, 1000);
            Controls.Add(panel5);
            Controls.Add(panel3);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "ADMIN";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ADMIN";
            Load += ADMIN_Load;
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel5.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel3;
        private Panel panel4;
        private PictureBox pictureBox2;
        private LinkLabel linkLabelLogout;
        private Panel panel2;
        private Panel panel11;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label3;
        private Button btnguest;
        private Button buttonreservation;
        private Button buttonroom;
        private Button buttonemployee;
        private Button buttonrevenue;
        private Button btndashboard;
        private Panel panelSlide;
        private Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private Label labelDateTime;
        private Label labelUsername;
        private Button btnaccount;
        private User_Control.accountuser accountuser1;
        private Button button1;
        private dashboarduser dashboarduser2;
        private Panel panel5;
        private dashboarduser dashboarduser1;
        private reservationuser reservationuser1;
        private revenue revenue1;
        private dashboarduser dashboarduser3;
        private dashboarduser dashboarduser4;
        private revenue revenue2;
        private EmployeeUser employeeUser2;
        private EmployeeUser employeeUser1;
        private RoomStatus roomStatus2;
        private RoomStatus roomStatus1;
        private accountuser accountuser2;
        private CheckInView checkInView1;
        private Button btnsuggest;
        private suggestionview suggestionview1;
    }
}