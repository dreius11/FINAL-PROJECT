﻿using FINAL_PROJECT.User_Control;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT
{
    public partial class ADMIN : Form
    {

        public ADMIN()
        {
            InitializeComponent();
            dashboarduser4.BringToFront();
        }

        public string username;

        private void Movepanel(Control btn)
        {
            panelSlide.Top = btn.Top;
            panelSlide.Height = btn.Height;
        }

        private void linkLabelLogout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
            this.Close();

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            labelDateTime.Text = DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt");
        }

        private void ADMIN_Load(object sender, EventArgs e)
        {

            timer1.Start();
            labelUsername.Text = $"Welcome, {username}!";
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            Movepanel(btndashboard);
            dashboarduser4.BringToFront();
        }

        private void buttonreservation_Click(object sender, EventArgs e)
        {
            Movepanel(buttonreservation);
            reservationuser1.BringToFront();
        }

        private void btnguest_Click(object sender, EventArgs e)
        {
            Movepanel(btnguest);
            checkInView1.BringToFront();

        }

        private void buttonroom_Click(object sender, EventArgs e)
        {
            Movepanel(buttonroom);
            roomStatus2.BringToFront();

        }

        private void buttonemployee_Click(object sender, EventArgs e)
        {
            Movepanel(buttonemployee);
            employeeUser2.BringToFront();
        }

        private void buttonrevenue_Click(object sender, EventArgs e)
        {
            Movepanel(buttonrevenue);
            revenue1.BringToFront();

        }

        private void btnaccount_Click(object sender, EventArgs e)
        {
            Movepanel(btnaccount);
            accountuser2.BringToFront();
        }
        private void RefreshAll()
        {

            dashboarduser4.LoadDashboard(); // You need to define this if not done

            // Refresh reservations
            reservationuser1.LoadReservationData();

            // Refresh check-in guest list
            checkInView1.LoadCheckedInData();
            checkInView1.LoadData();
            checkInView1.LoadCheckedInData();

            // Refresh room status
            roomStatus2.LoadRoomData(); // Create if needed

            // Refresh employee data
            employeeUser2.LoadData(); // Create if needed

            // Refresh account/user info
            accountuser2.LoadData(); // Create if needed

            // Update labels
            labelUsername.Text = $"Welcome, {username}!";
            labelDateTime.Text = DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt");
        }



        private void button1_Click(object sender, EventArgs e)
        {
            RefreshAll();
            MessageBox.Show("All data has been refreshed!", "Refresh", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnsuggest_Click(object sender, EventArgs e)
        {
            
            Movepanel(btnsuggest);
            suggestionview1.BringToFront();
        }
    }

}
