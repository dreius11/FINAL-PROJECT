﻿namespace FINAL_PROJECT.FORMS
{
    partial class Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Client));
            panel1 = new Panel();
            button3 = new Button();
            button2 = new Button();
            panelSlide = new Panel();
            btndashboard = new Button();
            buttonrevenue = new Button();
            buttonroom = new Button();
            buttonreservation = new Button();
            panel2 = new Panel();
            panel11 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            panel3 = new Panel();
            button1 = new Button();
            labelUsername = new Label();
            panel5 = new Panel();
            labeldate = new Label();
            logout = new LinkLabel();
            pictureBox3 = new PictureBox();
            panel4 = new Panel();
            clientsuggest1 = new FINAL_PROJECT.User_Control.clientsuggest();
            viewRoom1 = new FINAL_PROJECT.User_Control.ViewRoom();
            clientReserve1 = new FINAL_PROJECT.User_Control.ClientReserve();
            dashboarduser1 = new dashboarduser();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Teal;
            panel1.BackgroundImageLayout = ImageLayout.Stretch;
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(panelSlide);
            panel1.Controls.Add(btndashboard);
            panel1.Controls.Add(buttonrevenue);
            panel1.Controls.Add(buttonroom);
            panel1.Controls.Add(buttonreservation);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(222, 1000);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.None;
            button3.BackColor = Color.Teal;
            button3.BackgroundImageLayout = ImageLayout.None;
            button3.Cursor = Cursors.Hand;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(24, 537);
            button3.Margin = new Padding(5, 5, 5, 5);
            button3.Name = "button3";
            button3.Size = new Size(190, 52);
            button3.TabIndex = 8;
            button3.Text = "Suggetions";
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.None;
            button2.BackColor = Color.Teal;
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(24, 475);
            button2.Margin = new Padding(5, 5, 5, 5);
            button2.Name = "button2";
            button2.Size = new Size(190, 52);
            button2.TabIndex = 7;
            button2.Text = "  Room";
            button2.TextImageRelation = TextImageRelation.ImageBeforeText;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // panelSlide
            // 
            panelSlide.BackColor = Color.White;
            panelSlide.Location = new Point(14, 356);
            panelSlide.Margin = new Padding(3, 4, 3, 4);
            panelSlide.Name = "panelSlide";
            panelSlide.Size = new Size(6, 52);
            panelSlide.TabIndex = 0;
            // 
            // btndashboard
            // 
            btndashboard.Anchor = AnchorStyles.None;
            btndashboard.BackColor = Color.Teal;
            btndashboard.BackgroundImageLayout = ImageLayout.None;
            btndashboard.Cursor = Cursors.Hand;
            btndashboard.FlatAppearance.BorderSize = 0;
            btndashboard.FlatStyle = FlatStyle.Flat;
            btndashboard.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btndashboard.ForeColor = Color.White;
            btndashboard.Image = (Image)resources.GetObject("btndashboard.Image");
            btndashboard.ImageAlign = ContentAlignment.MiddleLeft;
            btndashboard.Location = new Point(27, 356);
            btndashboard.Margin = new Padding(5, 5, 5, 5);
            btndashboard.Name = "btndashboard";
            btndashboard.Size = new Size(190, 52);
            btndashboard.TabIndex = 1;
            btndashboard.Text = "  Dashboard";
            btndashboard.TextImageRelation = TextImageRelation.ImageBeforeText;
            btndashboard.UseVisualStyleBackColor = false;
            btndashboard.Click += btndashboard_Click;
            // 
            // buttonrevenue
            // 
            buttonrevenue.Anchor = AnchorStyles.None;
            buttonrevenue.BackColor = Color.Teal;
            buttonrevenue.BackgroundImageLayout = ImageLayout.None;
            buttonrevenue.Cursor = Cursors.Hand;
            buttonrevenue.FlatAppearance.BorderSize = 0;
            buttonrevenue.FlatStyle = FlatStyle.Flat;
            buttonrevenue.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonrevenue.ForeColor = Color.White;
            buttonrevenue.ImageAlign = ContentAlignment.MiddleLeft;
            buttonrevenue.Location = new Point(23, 1013);
            buttonrevenue.Margin = new Padding(5, 5, 5, 5);
            buttonrevenue.Name = "buttonrevenue";
            buttonrevenue.Size = new Size(190, 52);
            buttonrevenue.TabIndex = 6;
            buttonrevenue.Text = "Revenue";
            buttonrevenue.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonrevenue.UseVisualStyleBackColor = false;
            // 
            // buttonroom
            // 
            buttonroom.Anchor = AnchorStyles.None;
            buttonroom.BackColor = Color.Teal;
            buttonroom.BackgroundImageLayout = ImageLayout.None;
            buttonroom.Cursor = Cursors.Hand;
            buttonroom.FlatAppearance.BorderSize = 0;
            buttonroom.FlatStyle = FlatStyle.Flat;
            buttonroom.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonroom.ForeColor = Color.White;
            buttonroom.Image = (Image)resources.GetObject("buttonroom.Image");
            buttonroom.ImageAlign = ContentAlignment.MiddleLeft;
            buttonroom.Location = new Point(27, 481);
            buttonroom.Margin = new Padding(5, 5, 5, 5);
            buttonroom.Name = "buttonroom";
            buttonroom.Size = new Size(190, 52);
            buttonroom.TabIndex = 4;
            buttonroom.Text = "  Room";
            buttonroom.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonroom.UseVisualStyleBackColor = false;
            // 
            // buttonreservation
            // 
            buttonreservation.Anchor = AnchorStyles.None;
            buttonreservation.BackColor = Color.Teal;
            buttonreservation.BackgroundImageLayout = ImageLayout.None;
            buttonreservation.Cursor = Cursors.Hand;
            buttonreservation.FlatAppearance.BorderSize = 0;
            buttonreservation.FlatStyle = FlatStyle.Flat;
            buttonreservation.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonreservation.ForeColor = Color.White;
            buttonreservation.Image = (Image)resources.GetObject("buttonreservation.Image");
            buttonreservation.ImageAlign = ContentAlignment.MiddleLeft;
            buttonreservation.Location = new Point(27, 419);
            buttonreservation.Margin = new Padding(5, 5, 5, 5);
            buttonreservation.Name = "buttonreservation";
            buttonreservation.Size = new Size(190, 52);
            buttonreservation.TabIndex = 2;
            buttonreservation.Text = "  Reservation";
            buttonreservation.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonreservation.UseVisualStyleBackColor = false;
            buttonreservation.Click += buttonreservation_Click;
            // 
            // panel2
            // 
            panel2.BackgroundImageLayout = ImageLayout.None;
            panel2.Controls.Add(panel11);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(label3);
            panel2.Dock = DockStyle.Top;
            panel2.ForeColor = SystemColors.ControlLightLight;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(222, 216);
            panel2.TabIndex = 0;
            // 
            // panel11
            // 
            panel11.BackColor = Color.White;
            panel11.Dock = DockStyle.Bottom;
            panel11.Location = new Point(0, 212);
            panel11.Margin = new Padding(3, 4, 3, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(222, 4);
            panel11.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(74, 165);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(80, 28);
            label1.TabIndex = 56;
            label1.Text = "System";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(74, 40);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 64);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 55;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(10, 133);
            label3.Margin = new Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new Size(195, 28);
            label3.TabIndex = 54;
            label3.Text = "Hotel Management";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Teal;
            panel3.Controls.Add(button1);
            panel3.Controls.Add(labelUsername);
            panel3.Controls.Add(panel5);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(222, 0);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(1035, 193);
            panel3.TabIndex = 4;
            // 
            // button1
            // 
            button1.BackColor = Color.Transparent;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(928, 131);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(86, 31);
            button1.TabIndex = 2;
            button1.Text = "REFRESH";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // labelUsername
            // 
            labelUsername.AutoSize = true;
            labelUsername.BackColor = Color.Transparent;
            labelUsername.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold);
            labelUsername.ForeColor = Color.White;
            labelUsername.Location = new Point(6, 133);
            labelUsername.Name = "labelUsername";
            labelUsername.Size = new Size(29, 37);
            labelUsername.TabIndex = 1;
            labelUsername.Text = "?";
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(labeldate);
            panel5.Controls.Add(logout);
            panel5.Controls.Add(pictureBox3);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(1035, 88);
            panel5.TabIndex = 0;
            // 
            // labeldate
            // 
            labeldate.AutoSize = true;
            labeldate.BackColor = Color.Transparent;
            labeldate.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labeldate.ForeColor = Color.Teal;
            labeldate.Location = new Point(0, 60);
            labeldate.Name = "labeldate";
            labeldate.Size = new Size(21, 28);
            labeldate.TabIndex = 0;
            labeldate.Text = "?";
            // 
            // logout
            // 
            logout.AutoSize = true;
            logout.DisabledLinkColor = Color.FromArgb(37, 198, 218);
            logout.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            logout.LinkColor = Color.Teal;
            logout.Location = new Point(946, 39);
            logout.Name = "logout";
            logout.Size = new Size(83, 28);
            logout.TabIndex = 0;
            logout.TabStop = true;
            logout.Text = "Log Out";
            logout.LinkClicked += logout_LinkClicked;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.BackgroundImageLayout = ImageLayout.None;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(896, 27);
            pictureBox3.Margin = new Padding(3, 4, 3, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(43, 51);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // panel4
            // 
            panel4.Controls.Add(clientsuggest1);
            panel4.Controls.Add(viewRoom1);
            panel4.Controls.Add(clientReserve1);
            panel4.Controls.Add(dashboarduser1);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(222, 193);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(1035, 807);
            panel4.TabIndex = 5;
            // 
            // clientsuggest1
            // 
            clientsuggest1.BackColor = Color.White;
            clientsuggest1.Dock = DockStyle.Fill;
            clientsuggest1.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            clientsuggest1.Location = new Point(0, 0);
            clientsuggest1.Margin = new Padding(5, 5, 5, 5);
            clientsuggest1.Name = "clientsuggest1";
            clientsuggest1.Size = new Size(1035, 807);
            clientsuggest1.TabIndex = 3;
            clientsuggest1.Load += clientsuggest1_Load;
            // 
            // viewRoom1
            // 
            viewRoom1.BackColor = Color.White;
            viewRoom1.Dock = DockStyle.Fill;
            viewRoom1.Location = new Point(0, 0);
            viewRoom1.Margin = new Padding(3, 5, 3, 5);
            viewRoom1.Name = "viewRoom1";
            viewRoom1.Size = new Size(1035, 807);
            viewRoom1.TabIndex = 2;
            // 
            // clientReserve1
            // 
            clientReserve1.Dock = DockStyle.Fill;
            clientReserve1.Location = new Point(0, 0);
            clientReserve1.Margin = new Padding(3, 5, 3, 5);
            clientReserve1.Name = "clientReserve1";
            clientReserve1.Size = new Size(1035, 807);
            clientReserve1.TabIndex = 1;
            // 
            // dashboarduser1
            // 
            dashboarduser1.BackColor = Color.White;
            dashboarduser1.Dock = DockStyle.Fill;
            dashboarduser1.Location = new Point(0, 0);
            dashboarduser1.Margin = new Padding(3, 5, 3, 5);
            dashboarduser1.Name = "dashboarduser1";
            dashboarduser1.Size = new Size(1035, 807);
            dashboarduser1.TabIndex = 0;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick_1;
            // 
            // Client
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1257, 1000);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Client";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Client";
            Load += Client_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel4.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panelSlide;
        private Button btndashboard;
        private Button buttonrevenue;
        private Button buttonroom;
        private Button buttonreservation;
        private Panel panel2;
        private Panel panel11;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label3;
        private Panel panel3;
        private Label labelUsername;
        private Panel panel5;
        private Label labeldate;
        private LinkLabel logout;
        private PictureBox pictureBox3;
        private Panel panel4;
        private dashboarduser dashboarduser1;
        private User_Control.ClientReserve clientReserve1;
        private User_Control.ViewRoom viewRoom1;
        private System.Windows.Forms.Timer timer1;
        private Button button1;
        private Button button3;
        private Button button2;
        private User_Control.clientsuggest clientsuggest1;
    }
}