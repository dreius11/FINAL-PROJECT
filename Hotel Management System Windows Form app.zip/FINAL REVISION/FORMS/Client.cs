﻿using FINAL_PROJECT.User_Control;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace FINAL_PROJECT.FORMS
{
    public partial class Client : Form
    {
        public Client()
        {
            InitializeComponent();
            Movepanel(btndashboard);
            dashboarduser1.BringToFront();
        }
        private void Movepanel(Control btn)
        {
            panelSlide.Top = btn.Top;
            panelSlide.Height = btn.Height;
        }
        private void linkLabelLogout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to log out?", "Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Hide();
                Login login = new Login();
                login.ShowDialog();
                this.Close();
            }
        }

        private void Client_Load(object sender, EventArgs e)
        {
            timer1.Start();
            labelUsername.Text = $"Welcome, Guest!";
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            Movepanel(btndashboard);
            dashboarduser1.BringToFront();

        }

        private void buttonreservation_Click(object sender, EventArgs e)
        {
            Movepanel(buttonreservation);
            clientReserve1.BringToFront();
        }

        private void logout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
            this.Close();
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            labeldate.Text = DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clientReserve1.LoadReservationData();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Movepanel(buttonroom);
            viewRoom1.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Movepanel(button3);
            clientsuggest1.BringToFront();
        }

        private void clientsuggest1_Load(object sender, EventArgs e)
        {

        }
    }
}
