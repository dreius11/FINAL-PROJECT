﻿namespace FINAL_PROJECT.FORMS
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeForm));
            panel1 = new Panel();
            button3 = new Button();
            panelSlide = new Panel();
            btndashboard = new Button();
            buttonroom = new Button();
            buttonreservation = new Button();
            btnguest = new Button();
            panel2 = new Panel();
            panel11 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            panel3 = new Panel();
            button1 = new Button();
            labelUsername = new Label();
            panel5 = new Panel();
            labeldate = new Label();
            logout = new LinkLabel();
            pictureBox3 = new PictureBox();
            panel4 = new Panel();
            suggestionview1 = new User_Control.suggestionview();
            roomStatus1 = new User_Control.RoomStatus();
            checkInView1 = new User_Control.CheckInView();
            reservationuser1 = new User_Control.reservationuser();
            dashboarduser1 = new dashboarduser();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Teal;
            panel1.BackgroundImageLayout = ImageLayout.Stretch;
            panel1.Controls.Add(button3);
            panel1.Controls.Add(panelSlide);
            panel1.Controls.Add(btndashboard);
            panel1.Controls.Add(buttonroom);
            panel1.Controls.Add(buttonreservation);
            panel1.Controls.Add(btnguest);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(194, 750);
            panel1.TabIndex = 1;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.None;
            button3.BackColor = Color.Teal;
            button3.BackgroundImageLayout = ImageLayout.None;
            button3.Cursor = Cursors.Hand;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(21, 435);
            button3.Margin = new Padding(4);
            button3.Name = "button3";
            button3.Size = new Size(166, 39);
            button3.TabIndex = 9;
            button3.Text = "Suggetions";
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // panelSlide
            // 
            panelSlide.BackColor = Color.White;
            panelSlide.Location = new Point(12, 247);
            panelSlide.Name = "panelSlide";
            panelSlide.Size = new Size(5, 39);
            panelSlide.TabIndex = 0;
            // 
            // btndashboard
            // 
            btndashboard.Anchor = AnchorStyles.None;
            btndashboard.BackColor = Color.Teal;
            btndashboard.BackgroundImageLayout = ImageLayout.None;
            btndashboard.Cursor = Cursors.Hand;
            btndashboard.FlatAppearance.BorderSize = 0;
            btndashboard.FlatStyle = FlatStyle.Flat;
            btndashboard.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btndashboard.ForeColor = Color.White;
            btndashboard.Image = (Image)resources.GetObject("btndashboard.Image");
            btndashboard.ImageAlign = ContentAlignment.MiddleLeft;
            btndashboard.Location = new Point(23, 247);
            btndashboard.Margin = new Padding(4);
            btndashboard.Name = "btndashboard";
            btndashboard.Size = new Size(166, 39);
            btndashboard.TabIndex = 1;
            btndashboard.Text = "  Dashboard";
            btndashboard.TextImageRelation = TextImageRelation.ImageBeforeText;
            btndashboard.UseVisualStyleBackColor = false;
            btndashboard.Click += btndashboard_Click;
            // 
            // buttonroom
            // 
            buttonroom.Anchor = AnchorStyles.None;
            buttonroom.BackColor = Color.Teal;
            buttonroom.BackgroundImageLayout = ImageLayout.None;
            buttonroom.Cursor = Cursors.Hand;
            buttonroom.FlatAppearance.BorderSize = 0;
            buttonroom.FlatStyle = FlatStyle.Flat;
            buttonroom.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonroom.ForeColor = Color.White;
            buttonroom.Image = (Image)resources.GetObject("buttonroom.Image");
            buttonroom.ImageAlign = ContentAlignment.MiddleLeft;
            buttonroom.Location = new Point(23, 388);
            buttonroom.Margin = new Padding(4);
            buttonroom.Name = "buttonroom";
            buttonroom.Size = new Size(166, 39);
            buttonroom.TabIndex = 4;
            buttonroom.Text = "  Room";
            buttonroom.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonroom.UseVisualStyleBackColor = false;
            buttonroom.Click += buttonroom_Click;
            // 
            // buttonreservation
            // 
            buttonreservation.Anchor = AnchorStyles.None;
            buttonreservation.BackColor = Color.Teal;
            buttonreservation.BackgroundImageLayout = ImageLayout.None;
            buttonreservation.Cursor = Cursors.Hand;
            buttonreservation.FlatAppearance.BorderSize = 0;
            buttonreservation.FlatStyle = FlatStyle.Flat;
            buttonreservation.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonreservation.ForeColor = Color.White;
            buttonreservation.Image = (Image)resources.GetObject("buttonreservation.Image");
            buttonreservation.ImageAlign = ContentAlignment.MiddleLeft;
            buttonreservation.Location = new Point(24, 294);
            buttonreservation.Margin = new Padding(4);
            buttonreservation.Name = "buttonreservation";
            buttonreservation.Size = new Size(166, 39);
            buttonreservation.TabIndex = 2;
            buttonreservation.Text = "  Reservation";
            buttonreservation.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttonreservation.UseVisualStyleBackColor = false;
            buttonreservation.Click += buttonreservation_Click;
            // 
            // btnguest
            // 
            btnguest.Anchor = AnchorStyles.None;
            btnguest.BackColor = Color.Teal;
            btnguest.BackgroundImageLayout = ImageLayout.None;
            btnguest.Cursor = Cursors.Hand;
            btnguest.FlatAppearance.BorderSize = 0;
            btnguest.FlatStyle = FlatStyle.Flat;
            btnguest.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnguest.ForeColor = Color.White;
            btnguest.Image = (Image)resources.GetObject("btnguest.Image");
            btnguest.ImageAlign = ContentAlignment.MiddleLeft;
            btnguest.Location = new Point(23, 341);
            btnguest.Margin = new Padding(4);
            btnguest.Name = "btnguest";
            btnguest.RightToLeft = RightToLeft.No;
            btnguest.Size = new Size(166, 39);
            btnguest.TabIndex = 3;
            btnguest.Text = "  Guest";
            btnguest.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnguest.UseVisualStyleBackColor = false;
            btnguest.Click += btnguest_Click;
            // 
            // panel2
            // 
            panel2.BackgroundImageLayout = ImageLayout.None;
            panel2.Controls.Add(panel11);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(label3);
            panel2.Dock = DockStyle.Top;
            panel2.ForeColor = SystemColors.ControlLightLight;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(194, 162);
            panel2.TabIndex = 0;
            // 
            // panel11
            // 
            panel11.BackColor = Color.White;
            panel11.Dock = DockStyle.Bottom;
            panel11.Location = new Point(0, 159);
            panel11.Name = "panel11";
            panel11.Size = new Size(194, 3);
            panel11.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(57, 112);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(75, 25);
            label1.TabIndex = 56;
            label1.Text = "System";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(68, 20);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(64, 64);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 55;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(0, 87);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(192, 25);
            label3.TabIndex = 54;
            label3.Text = "Hostel Management";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Teal;
            panel3.Controls.Add(button1);
            panel3.Controls.Add(labelUsername);
            panel3.Controls.Add(panel5);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(194, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(906, 145);
            panel3.TabIndex = 3;
            // 
            // button1
            // 
            button1.BackColor = Color.Transparent;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(819, 100);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "REFRESH";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // labelUsername
            // 
            labelUsername.AutoSize = true;
            labelUsername.BackColor = Color.Transparent;
            labelUsername.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold);
            labelUsername.ForeColor = Color.White;
            labelUsername.Location = new Point(5, 100);
            labelUsername.Name = "labelUsername";
            labelUsername.Size = new Size(22, 30);
            labelUsername.TabIndex = 1;
            labelUsername.Text = "?";
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(labeldate);
            panel5.Controls.Add(logout);
            panel5.Controls.Add(pictureBox3);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(906, 66);
            panel5.TabIndex = 0;
            // 
            // labeldate
            // 
            labeldate.AutoSize = true;
            labeldate.BackColor = Color.Transparent;
            labeldate.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labeldate.ForeColor = Color.Teal;
            labeldate.Location = new Point(0, 45);
            labeldate.Name = "labeldate";
            labeldate.Size = new Size(17, 21);
            labeldate.TabIndex = 0;
            labeldate.Text = "?";
            // 
            // logout
            // 
            logout.AutoSize = true;
            logout.DisabledLinkColor = Color.FromArgb(37, 198, 218);
            logout.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            logout.LinkColor = Color.Teal;
            logout.Location = new Point(828, 29);
            logout.Name = "logout";
            logout.Size = new Size(66, 21);
            logout.TabIndex = 0;
            logout.TabStop = true;
            logout.Text = "Log Out";
            logout.LinkClicked += logout_LinkClicked;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Transparent;
            pictureBox3.BackgroundImageLayout = ImageLayout.None;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(784, 20);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(38, 38);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // panel4
            // 
            panel4.Controls.Add(suggestionview1);
            panel4.Controls.Add(roomStatus1);
            panel4.Controls.Add(checkInView1);
            panel4.Controls.Add(reservationuser1);
            panel4.Controls.Add(dashboarduser1);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(194, 145);
            panel4.Name = "panel4";
            panel4.Size = new Size(906, 605);
            panel4.TabIndex = 4;
            // 
            // suggestionview1
            // 
            suggestionview1.BackColor = Color.White;
            suggestionview1.Dock = DockStyle.Fill;
            suggestionview1.Location = new Point(0, 0);
            suggestionview1.Name = "suggestionview1";
            suggestionview1.Size = new Size(906, 605);
            suggestionview1.TabIndex = 4;
            // 
            // roomStatus1
            // 
            roomStatus1.Dock = DockStyle.Fill;
            roomStatus1.Location = new Point(0, 0);
            roomStatus1.Name = "roomStatus1";
            roomStatus1.Size = new Size(906, 605);
            roomStatus1.TabIndex = 3;
            // 
            // checkInView1
            // 
            checkInView1.Dock = DockStyle.Fill;
            checkInView1.Location = new Point(0, 0);
            checkInView1.Name = "checkInView1";
            checkInView1.Size = new Size(906, 605);
            checkInView1.TabIndex = 2;
            // 
            // reservationuser1
            // 
            reservationuser1.Dock = DockStyle.Fill;
            reservationuser1.Location = new Point(0, 0);
            reservationuser1.Name = "reservationuser1";
            reservationuser1.Size = new Size(906, 605);
            reservationuser1.TabIndex = 1;
            // 
            // dashboarduser1
            // 
            dashboarduser1.BackColor = Color.White;
            dashboarduser1.Dock = DockStyle.Fill;
            dashboarduser1.Location = new Point(0, 0);
            dashboarduser1.Name = "dashboarduser1";
            dashboarduser1.Size = new Size(906, 605);
            dashboarduser1.TabIndex = 0;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // EmployeeForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1100, 750);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "EmployeeForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EmployeeForm";
            Load += EmployeeForm_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel4.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panelSlide;
        private Button btndashboard;
        private Button buttonroom;
        private Button buttonreservation;
        private Button btnguest;
        private Panel panel2;
        private Panel panel11;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label3;
        private Panel panel3;
        private Button button1;
        private Label labelUsername;
        private Panel panel5;
        private Label labeldate;
        private LinkLabel logout;
        private PictureBox pictureBox3;
        private Panel panel4;
        private User_Control.reservationuser reservationuser1;
        private dashboarduser dashboarduser1;
        private User_Control.CheckInView checkinReserveView1;
        private System.Windows.Forms.Timer timer1;
        private User_Control.CheckInView checkInView1;
        private Button button3;
        private User_Control.RoomStatus roomStatus1;
        private User_Control.suggestionview suggestionview1;
    }
}