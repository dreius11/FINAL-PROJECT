﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT.FORMS
{

    public partial class EmployeeForm : Form
    {
        public string username;
        public EmployeeForm()
        {
            InitializeComponent();
            dashboarduser1.BringToFront();
        }

        private void Movepanel(Control btn)
        {
            panelSlide.Top = btn.Top;
            panelSlide.Height = btn.Height;
        }

        private void RefreshAll()
        {

            reservationuser1.LoadReservationData();
            checkinReserveView1.LoadData();
            checkinReserveView1.LoadCheckedInData();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            RefreshAll();
            MessageBox.Show("All data has been refreshed!", "Refresh", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void logout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
            this.Close();
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            Movepanel(btndashboard);
            dashboarduser1.BringToFront();
        }

        private void buttonreservation_Click(object sender, EventArgs e)
        {
            Movepanel(buttonreservation);
            reservationuser1.BringToFront();
        }

        private void btnguest_Click(object sender, EventArgs e)
        {
            Movepanel(btnguest);
            checkInView1.BringToFront();
        }

        private void buttonroom_Click(object sender, EventArgs e)
        {
            Movepanel(buttonroom);
            roomStatus1.BringToFront();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            labeldate.Text = DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt");
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {

            timer1.Start();
            labelUsername.Text = $"Welcome, {username}!";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Movepanel(button3);
            suggestionview1.BringToFront();
        }

    }

}


