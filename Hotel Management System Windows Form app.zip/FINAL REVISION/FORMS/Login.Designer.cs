﻿namespace FINAL_PROJECT
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            pictureBoxclose = new PictureBox();
            pictureBoxminimize = new PictureBox();
            toolTip1 = new ToolTip(components);
            groupBox1 = new GroupBox();
            showconfirm = new CheckBox();
            label1 = new Label();
            txtusername = new TextBox();
            label4 = new Label();
            label2 = new Label();
            txtpassword = new TextBox();
            btnlogin = new Button();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            label5 = new Label();
            panel2 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBoxclose).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxminimize).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBoxclose
            // 
            pictureBoxclose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBoxclose.Cursor = Cursors.Hand;
            pictureBoxclose.Image = (Image)resources.GetObject("pictureBoxclose.Image");
            pictureBoxclose.Location = new Point(1006, 0);
            pictureBoxclose.Margin = new Padding(4);
            pictureBoxclose.Name = "pictureBoxclose";
            pictureBoxclose.Size = new Size(28, 34);
            pictureBoxclose.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxclose.TabIndex = 0;
            pictureBoxclose.TabStop = false;
            pictureBoxclose.Click += pictureBoxclose_Click;
            // 
            // pictureBoxminimize
            // 
            pictureBoxminimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBoxminimize.Cursor = Cursors.Hand;
            pictureBoxminimize.Image = (Image)resources.GetObject("pictureBoxminimize.Image");
            pictureBoxminimize.Location = new Point(970, 0);
            pictureBoxminimize.Margin = new Padding(4);
            pictureBoxminimize.Name = "pictureBoxminimize";
            pictureBoxminimize.Size = new Size(28, 34);
            pictureBoxminimize.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxminimize.TabIndex = 1;
            pictureBoxminimize.TabStop = false;
            pictureBoxminimize.Click += pictureBoxminimize_Click;
            pictureBoxminimize.MouseHover += pictureBoxminimize_MouseHover;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.BackgroundImage = (Image)resources.GetObject("groupBox1.BackgroundImage");
            groupBox1.BackgroundImageLayout = ImageLayout.Stretch;
            groupBox1.Controls.Add(showconfirm);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtusername);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtpassword);
            groupBox1.Controls.Add(btnlogin);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.FlatStyle = FlatStyle.Flat;
            groupBox1.Font = new Font("Nirmala UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(0, 0);
            groupBox1.Margin = new Padding(4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4);
            groupBox1.Size = new Size(300, 544);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Welcome!";
            // 
            // showconfirm
            // 
            showconfirm.Anchor = AnchorStyles.None;
            showconfirm.AutoSize = true;
            showconfirm.BackColor = Color.Transparent;
            showconfirm.Cursor = Cursors.Hand;
            showconfirm.Font = new Font("Nirmala UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            showconfirm.ForeColor = Color.White;
            showconfirm.Location = new Point(26, 319);
            showconfirm.Margin = new Padding(4);
            showconfirm.Name = "showconfirm";
            showconfirm.Size = new Size(135, 23);
            showconfirm.TabIndex = 47;
            showconfirm.Text = "Show password";
            showconfirm.UseVisualStyleBackColor = false;
            showconfirm.CheckedChanged += showconfirm_CheckedChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(26, 149);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(106, 28);
            label1.TabIndex = 43;
            label1.Text = "Username";
            // 
            // txtusername
            // 
            txtusername.BackColor = Color.WhiteSmoke;
            txtusername.BorderStyle = BorderStyle.FixedSingle;
            txtusername.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtusername.ForeColor = Color.Black;
            txtusername.Location = new Point(26, 181);
            txtusername.Margin = new Padding(4);
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(233, 34);
            txtusername.TabIndex = 44;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Cursor = Cursors.Hand;
            label4.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(65, 429);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(156, 28);
            label4.TabIndex = 49;
            label4.Text = "Log in as Guest";
            label4.Click += label4_Click;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(26, 247);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(100, 28);
            label2.TabIndex = 45;
            label2.Text = "Password";
            // 
            // txtpassword
            // 
            txtpassword.Anchor = AnchorStyles.None;
            txtpassword.BackColor = Color.WhiteSmoke;
            txtpassword.BorderStyle = BorderStyle.FixedSingle;
            txtpassword.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtpassword.ForeColor = Color.Black;
            txtpassword.Location = new Point(26, 279);
            txtpassword.Margin = new Padding(4);
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(233, 34);
            txtpassword.TabIndex = 46;
            // 
            // btnlogin
            // 
            btnlogin.Anchor = AnchorStyles.None;
            btnlogin.BackColor = Color.Teal;
            btnlogin.Cursor = Cursors.Hand;
            btnlogin.FlatAppearance.BorderSize = 0;
            btnlogin.FlatStyle = FlatStyle.Flat;
            btnlogin.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnlogin.ForeColor = Color.White;
            btnlogin.Location = new Point(26, 386);
            btnlogin.Margin = new Padding(4);
            btnlogin.Name = "btnlogin";
            btnlogin.Size = new Size(233, 39);
            btnlogin.TabIndex = 48;
            btnlogin.Text = "Log In";
            btnlogin.UseVisualStyleBackColor = false;
            btnlogin.Click += btnlogin_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Location = new Point(492, -7);
            panel1.Margin = new Padding(6, 4, 6, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(10, 681);
            panel1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(610, 187);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(373, 235);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nirmala UI", 21.75F, FontStyle.Bold);
            label3.ForeColor = Color.Teal;
            label3.Location = new Point(620, 406);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(358, 50);
            label3.TabIndex = 53;
            label3.Text = "Hotel Management";
            label3.Click += label3_Click;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Nirmala UI", 21.75F, FontStyle.Bold);
            label5.ForeColor = Color.Teal;
            label5.Location = new Point(720, 446);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(146, 50);
            label5.TabIndex = 54;
            label5.Text = "System";
            // 
            // panel2
            // 
            panel2.Controls.Add(groupBox1);
            panel2.Location = new Point(86, 87);
            panel2.Name = "panel2";
            panel2.Size = new Size(300, 544);
            panel2.TabIndex = 55;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(16F, 36F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1038, 670);
            Controls.Add(panel2);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(pictureBoxminimize);
            Controls.Add(pictureBoxclose);
            Controls.Add(label5);
            DoubleBuffered = true;
            Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = Color.RoyalBlue;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4);
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            ((System.ComponentModel.ISupportInitialize)pictureBoxclose).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxminimize).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBoxclose;
        private PictureBox pictureBoxminimize;
        private ToolTip toolTip1;
        private GroupBox groupBox1;
        private CheckBox showconfirm;
        private Label label1;
        private TextBox txtusername;
        private Label label4;
        private Label label2;
        private TextBox txtpassword;
        private Button btnlogin;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Label label3;
        private Label label5;
        private Panel panel2;
    }
}