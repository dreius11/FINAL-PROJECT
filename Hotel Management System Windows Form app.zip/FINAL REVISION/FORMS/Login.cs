﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using FINAL_PROJECT.FORMS;

namespace FINAL_PROJECT
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            txtpassword.PasswordChar = '*';
            txtusername.KeyDown += new KeyEventHandler(txtusername_KeyDown);
            txtpassword.KeyDown += new KeyEventHandler(txtpassword_KeyDown);

        }

        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb");
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter da = new OleDbDataAdapter();

        private void txtusername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) // If Enter is pressed
            {
                e.Handled = true;  // Prevent default behavior (such as adding space or submitting)
                txtpassword.Focus(); // Move the focus to the password TextBox
            }
        }

        private void txtpassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) // If Enter is pressed
            {
                e.Handled = true;  // Prevent default behavior
                btnlogin.PerformClick(); // Simulate the login button click
            }
        }


        private void pictureBoxminimize_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBoxminimize, "Minimize");
        }

        private void pictureBoxclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBoxminimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                string adminQuery = "SELECT * FROM [AdminLogIn] WHERE Username = ? AND Password = ?";
                cmd = new OleDbCommand(adminQuery, con);
                cmd.Parameters.AddWithValue("?", txtusername.Text);
                cmd.Parameters.AddWithValue("?", txtpassword.Text);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    dr.Close();
                    ADMIN admin = new ADMIN();
                    admin.username = txtusername.Text;
                    this.Hide();
                    admin.ShowDialog();
                }
                else
                {
                    dr.Close(); // Close the first reader

                    // Try Employee Login
                    string empQuery = "SELECT * FROM [EmployeeLogIn] WHERE Username = ? AND Password = ?";
                    cmd = new OleDbCommand(empQuery, con);
                    cmd.Parameters.AddWithValue("?", txtusername.Text);
                    cmd.Parameters.AddWithValue("?", txtpassword.Text);

                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        dr.Close();
                        EmployeeForm empForm = new EmployeeForm();
                        empForm.username = txtusername.Text;
                        this.Hide();
                        empForm.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password!", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtpassword.Clear();
                        txtusername.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }

        }

        private void showconfirm_CheckedChanged(object sender, EventArgs e)
        {
            if (showconfirm.Checked)
            {
                txtpassword.PasswordChar = '\0';
            }
            else
            {
                txtpassword.PasswordChar = '*';
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Client clientForm = new Client();
            this.Hide();
            clientForm.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
