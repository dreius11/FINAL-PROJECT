﻿namespace FINAL_PROJECT.User_Control
{
    partial class CheckInView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            chicken = new TabPage();
            dgv1 = new DataGridView();
            panel1 = new Panel();
            CheckIn = new Button();
            paymentMethod = new ComboBox();
            searchbutton = new Button();
            searchBox1 = new TextBox();
            CheckOut = new TabPage();
            dgv2 = new DataGridView();
            panel2 = new Panel();
            Checkoutbutoon = new Button();
            searchcheckout = new Button();
            comboBoxRoomType = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            searchBox2 = new TextBox();
            tabControl1.SuspendLayout();
            chicken.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv1).BeginInit();
            panel1.SuspendLayout();
            CheckOut.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv2).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(chicken);
            tabControl1.Controls.Add(CheckOut);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(3, 4, 3, 4);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1035, 807);
            tabControl1.TabIndex = 0;
            // 
            // chicken
            // 
            chicken.Controls.Add(dgv1);
            chicken.Controls.Add(panel1);
            chicken.Location = new Point(4, 4);
            chicken.Margin = new Padding(3, 4, 3, 4);
            chicken.Name = "chicken";
            chicken.Padding = new Padding(3, 4, 3, 4);
            chicken.Size = new Size(1027, 766);
            chicken.TabIndex = 0;
            chicken.Text = "Check In";
            chicken.UseVisualStyleBackColor = true;
            // 
            // dgv1
            // 
            dgv1.BackgroundColor = Color.White;
            dgv1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv1.Dock = DockStyle.Fill;
            dgv1.Location = new Point(3, 127);
            dgv1.Margin = new Padding(3, 4, 3, 4);
            dgv1.Name = "dgv1";
            dgv1.RowHeadersWidth = 51;
            dgv1.Size = new Size(1021, 635);
            dgv1.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.Controls.Add(CheckIn);
            panel1.Controls.Add(paymentMethod);
            panel1.Controls.Add(searchbutton);
            panel1.Controls.Add(searchBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(3, 4);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1021, 123);
            panel1.TabIndex = 0;
            // 
            // CheckIn
            // 
            CheckIn.BackColor = Color.Teal;
            CheckIn.BackgroundImageLayout = ImageLayout.None;
            CheckIn.FlatStyle = FlatStyle.Flat;
            CheckIn.ForeColor = Color.White;
            CheckIn.Location = new Point(840, 37);
            CheckIn.Margin = new Padding(3, 4, 3, 4);
            CheckIn.Name = "CheckIn";
            CheckIn.Size = new Size(112, 39);
            CheckIn.TabIndex = 3;
            CheckIn.Text = "Check In";
            CheckIn.UseVisualStyleBackColor = false;
            CheckIn.Click += CheckIn_Click;
            // 
            // paymentMethod
            // 
            paymentMethod.FormattingEnabled = true;
            paymentMethod.Items.AddRange(new object[] { "Cash", "Gcash", "Paymaya", "Banktransfer" });
            paymentMethod.Location = new Point(630, 37);
            paymentMethod.Margin = new Padding(3, 4, 3, 4);
            paymentMethod.Name = "paymentMethod";
            paymentMethod.Size = new Size(203, 36);
            paymentMethod.TabIndex = 2;
            // 
            // searchbutton
            // 
            searchbutton.BackColor = Color.Teal;
            searchbutton.BackgroundImageLayout = ImageLayout.None;
            searchbutton.FlatStyle = FlatStyle.Flat;
            searchbutton.ForeColor = Color.White;
            searchbutton.Location = new Point(333, 37);
            searchbutton.Margin = new Padding(3, 4, 3, 4);
            searchbutton.Name = "searchbutton";
            searchbutton.Size = new Size(112, 39);
            searchbutton.TabIndex = 1;
            searchbutton.Text = "Search";
            searchbutton.UseVisualStyleBackColor = false;
            searchbutton.Click += searchbutton_Click;
            // 
            // searchBox1
            // 
            searchBox1.Location = new Point(7, 37);
            searchBox1.Margin = new Padding(3, 4, 3, 4);
            searchBox1.Name = "searchBox1";
            searchBox1.Size = new Size(318, 34);
            searchBox1.TabIndex = 0;
            // 
            // CheckOut
            // 
            CheckOut.Controls.Add(dgv2);
            CheckOut.Controls.Add(panel2);
            CheckOut.Location = new Point(4, 4);
            CheckOut.Margin = new Padding(3, 4, 3, 4);
            CheckOut.Name = "CheckOut";
            CheckOut.Padding = new Padding(3, 4, 3, 4);
            CheckOut.Size = new Size(1027, 766);
            CheckOut.TabIndex = 1;
            CheckOut.Text = "Check Out";
            CheckOut.UseVisualStyleBackColor = true;
            // 
            // dgv2
            // 
            dgv2.BackgroundColor = Color.White;
            dgv2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv2.Dock = DockStyle.Fill;
            dgv2.Location = new Point(3, 105);
            dgv2.Margin = new Padding(3, 4, 3, 4);
            dgv2.Name = "dgv2";
            dgv2.RowHeadersWidth = 51;
            dgv2.Size = new Size(1021, 657);
            dgv2.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Teal;
            panel2.Controls.Add(Checkoutbutoon);
            panel2.Controls.Add(searchcheckout);
            panel2.Controls.Add(comboBoxRoomType);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(searchBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(3, 4);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(1021, 101);
            panel2.TabIndex = 0;
            // 
            // Checkoutbutoon
            // 
            Checkoutbutoon.BackColor = Color.White;
            Checkoutbutoon.FlatStyle = FlatStyle.Flat;
            Checkoutbutoon.ForeColor = Color.Teal;
            Checkoutbutoon.Location = new Point(855, 25);
            Checkoutbutoon.Margin = new Padding(3, 4, 3, 4);
            Checkoutbutoon.Name = "Checkoutbutoon";
            Checkoutbutoon.Size = new Size(133, 41);
            Checkoutbutoon.TabIndex = 6;
            Checkoutbutoon.Text = "Check Out";
            Checkoutbutoon.UseVisualStyleBackColor = false;
            Checkoutbutoon.Click += Checkoutbutoon_Click;
            // 
            // searchcheckout
            // 
            searchcheckout.BackColor = Color.White;
            searchcheckout.FlatStyle = FlatStyle.Flat;
            searchcheckout.ForeColor = Color.Teal;
            searchcheckout.Location = new Point(715, 25);
            searchcheckout.Margin = new Padding(3, 4, 3, 4);
            searchcheckout.Name = "searchcheckout";
            searchcheckout.Size = new Size(133, 41);
            searchcheckout.TabIndex = 5;
            searchcheckout.Text = "Search";
            searchcheckout.UseVisualStyleBackColor = false;
            searchcheckout.Click += searchcheckout_Click;
            // 
            // comboBoxRoomType
            // 
            comboBoxRoomType.FormattingEnabled = true;
            comboBoxRoomType.Items.AddRange(new object[] { "Standard Room", "Deluxe Room", "Barkada Room", "Family Room" });
            comboBoxRoomType.Location = new Point(449, 25);
            comboBoxRoomType.Margin = new Padding(3, 4, 3, 4);
            comboBoxRoomType.Name = "comboBoxRoomType";
            comboBoxRoomType.Size = new Size(174, 36);
            comboBoxRoomType.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.White;
            label2.Location = new Point(342, 29);
            label2.Name = "label2";
            label2.Size = new Size(110, 28);
            label2.TabIndex = 3;
            label2.Text = "Room Type";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.White;
            label1.Location = new Point(17, 29);
            label1.Name = "label1";
            label1.Size = new Size(64, 28);
            label1.TabIndex = 2;
            label1.Text = "Name";
            // 
            // searchBox2
            // 
            searchBox2.Location = new Point(83, 25);
            searchBox2.Margin = new Padding(3, 4, 3, 4);
            searchBox2.Name = "searchBox2";
            searchBox2.Size = new Size(217, 34);
            searchBox2.TabIndex = 0;
            // 
            // CheckInView
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tabControl1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "CheckInView";
            Size = new Size(1035, 807);
            tabControl1.ResumeLayout(false);
            chicken.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            CheckOut.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgv2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage chicken;
        private Panel panel1;
        private Button button2;
        private Button CheckIn;
        private ComboBox paymentMethod;
        private Button searchbutton;
        private TextBox searchBox1;
        private TabPage CheckOut;
        private DataGridView dgv1;
        private DataGridView dgv2;
        private Panel panel2;
        private Button Checkoutbutoon;
        private Button searchcheckout;
        private ComboBox comboBoxRoomType;
        private Label label2;
        private Label label1;
        private TextBox searchBox2;
    }
}
