﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using QRCoder;
using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FINAL_PROJECT.User_Control
{
    public partial class CheckInView : UserControl
    {


        public CheckInView()
        {
            InitializeComponent();
            this.Load += CheckInView_Load;
        }
        
        private void CheckInView_Load(object sender, EventArgs e)
        {
            if (!DesignMode)
            {
                LoadData();
                LoadCheckedInData();
            }
        }

        private void searchbutton_Click(object sender, EventArgs e)
        {
            string keyword = searchBox1.Text.Trim();

            using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
            {
                con.Open();
                string query = "SELECT * FROM Reservation WHERE FirstName LIKE ? OR MobileNo LIKE ? OR RoomType LIKE ?";
                using (OleDbCommand cmd = new OleDbCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("?", "%" + keyword + "%");
                    cmd.Parameters.AddWithValue("?", "%" + keyword + "%");
                    cmd.Parameters.AddWithValue("?", "%" + keyword + "%");

                    OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgv1.DataSource = dt;
                }
                con.Close();
            }
            searchBox1.Clear();
           
        }

        private void CheckIn_Click(object sender, EventArgs e)
        {
            if (dgv1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a reservation to check in.");
                return;
            }

            // Get data from selected row
            DataGridViewRow row = dgv1.SelectedRows[0];
            int id = Convert.ToInt32(row.Cells["Id"].Value);
            string firstName = row.Cells["FirstName"].Value.ToString();
            string mobileNo = row.Cells["MobileNo"].Value.ToString();
            string roomType = row.Cells["RoomType"].Value.ToString();
            string gender = row.Cells["Gender"].Value.ToString();
            string address = row.Cells["Address"].Value.ToString();
            string nationality = row.Cells["Nationality"].Value.ToString();
            string Email = row.Cells["Email"].Value.ToString();
            DateTime checkinDate = Convert.ToDateTime(row.Cells["Checkin"].Value);
            DateTime checkoutDate = Convert.ToDateTime(row.Cells["CheckOut"].Value);
            double totalCost = Convert.ToDouble(row.Cells["TotalCost"].Value);
            double downPayment = Convert.ToDouble(row.Cells["Downpayment"].Value);
            double balance = totalCost - downPayment;

            string selectedPaymentMethod = paymentMethod.SelectedItem?.ToString().Trim();
            if (string.IsNullOrWhiteSpace(selectedPaymentMethod))
            {
                MessageBox.Show("Please select a payment method.", "Missing Payment Method", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string referenceCode = string.Empty;

            switch (selectedPaymentMethod)
            {
                case "Gcash":
                case "Paymaya":
                case "Banktransfer":
                    // Show QR
                    GenerateQRCode(selectedPaymentMethod, balance);

                    MessageBox.Show($"Please scan the QR code to pay the remaining balance using {selectedPaymentMethod}.",
                        "Payment Required", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    string referenceNumber = Microsoft.VisualBasic.Interaction.InputBox(
                        "Enter your payment reference number after completing the payment:",
                        "Reference Number Required"
                    );

                    if (string.IsNullOrWhiteSpace(referenceNumber))
                    {
                        MessageBox.Show("You must enter a valid reference number to proceed.", "Missing Reference Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    referenceCode = referenceNumber;
                    break;

                case "Cash":
                    MessageBox.Show($"Please prepare ₱{balance:N2} for cash payment.", "Cash Payment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    referenceCode = "CASH" + DateTime.Now.Ticks.ToString(); // Auto-generate reference
                    break;

                default:
                    MessageBox.Show("Invalid payment method selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
            }

            // Insert to CheckedIn table
            using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
            {
                con.Open();

                string insertQuery = "INSERT INTO CheckedIn (FirstName, MobileNo, Nationality, Gender, Address, Email, Checkin, CheckOut, RoomType, PaymentMode, Downpayment, ReferenceCode, TotalCost) " +
                                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                using (OleDbCommand cmd = new OleDbCommand(insertQuery, con))
                {
                    cmd.Parameters.AddWithValue("?", firstName);
                    cmd.Parameters.AddWithValue("?", mobileNo);
                    cmd.Parameters.AddWithValue("?", nationality);
                    cmd.Parameters.AddWithValue("?", gender);
                    cmd.Parameters.AddWithValue("?", address);
                    cmd.Parameters.AddWithValue("?", Email);
                    cmd.Parameters.AddWithValue("?", checkinDate);
                    cmd.Parameters.AddWithValue("?", checkoutDate);
                    cmd.Parameters.AddWithValue("?", roomType);
                    cmd.Parameters.AddWithValue("?", selectedPaymentMethod);
                    cmd.Parameters.AddWithValue("?", downPayment);
                    cmd.Parameters.AddWithValue("?", referenceCode);
                    cmd.Parameters.AddWithValue("?", totalCost);

                    cmd.ExecuteNonQuery();
                }

                // Remove reservation from Reservation table
                string deleteQuery = "DELETE FROM Reservation WHERE Id = ?";
                using (OleDbCommand deleteCmd = new OleDbCommand(deleteQuery, con))
                {
                    deleteCmd.Parameters.AddWithValue("?", id);
                    deleteCmd.ExecuteNonQuery();
                }

                foreach (DataGridViewRow selectedRow in dgv1.SelectedRows)
                {
                    dgv1.Rows.Remove(selectedRow);
                }

                con.Close();
            }

            MessageBox.Show("Check-in successful. Guest has been added to CheckedIn.");
            LoadData(); // Refresh available reservations
            LoadCheckedInData(); // Refresh checked-in guests
        }
       

        private void searchcheckout_Click(object sender, EventArgs e)
        {
            string keyword = searchBox2.Text.Trim();
            string selectedRoomType = comboBoxRoomType.SelectedItem?.ToString();

            using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
            {
                con.Open();

                StringBuilder query = new StringBuilder("SELECT * FROM CheckedIn WHERE (FirstName LIKE ? OR MobileNo LIKE ?)");
                if (selectedRoomType != "All" && !string.IsNullOrWhiteSpace(selectedRoomType))
                {
                    query.Append(" AND RoomType = ?");
                }

                using (OleDbCommand cmd = new OleDbCommand(query.ToString(), con))
                {
                    cmd.Parameters.AddWithValue("?", "%" + keyword + "%");
                    cmd.Parameters.AddWithValue("?", "%" + keyword + "%");

                    if (selectedRoomType != "All" && !string.IsNullOrWhiteSpace(selectedRoomType))
                    {
                        cmd.Parameters.AddWithValue("?", selectedRoomType);
                    }

                    OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgv2.DataSource = dt;
                }

                con.Close();
            }
            searchBox2.Clear();
            comboBoxRoomType.SelectedIndex = 0;
           
        }

        private void Checkoutbutoon_Click(object sender, EventArgs e)
        {
            if (dgv2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a checked-in guest to check out.");
                return;
            }

            DataGridViewRow row = dgv2.SelectedRows[0];
            string id = row.Cells["Id"].Value.ToString();
            string firstName = row.Cells["FirstName"].Value.ToString();
            string mobileNo = row.Cells["MobileNo"].Value.ToString();
            string roomType = row.Cells["RoomType"].Value.ToString();
            string gender = row.Cells["Gender"].Value.ToString();
            string address = row.Cells["Address"].Value.ToString();
            string nationality = row.Cells["Nationality"].Value.ToString();
            string Email = row.Cells["Email"].Value.ToString();
            DateTime checkinDate = Convert.ToDateTime(row.Cells["Checkin"].Value);
            DateTime checkoutDate = Convert.ToDateTime(row.Cells["CheckOut"].Value);
            double totalCost = Convert.ToDouble(row.Cells["TotalCost"].Value);
            double downPayment = Convert.ToDouble(row.Cells["Downpayment"].Value);
            string paymentMethod = row.Cells["PaymentMode"].Value.ToString();
            string referenceCode = row.Cells["ReferenceCode"].Value.ToString();

            using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
            {
                con.Open();

                // 1. Insert into Checkout table
                string insertQuery = "INSERT INTO Checkout (FirstName, MobileNo, Nationality, Gender, Address, Email, Checkin, CheckOut, RoomType, PaymentMethod, ReferenceCode, Downpayment, TotalCost) " +
                                     "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                using (OleDbCommand cmd = new OleDbCommand(insertQuery, con))
                {
                    cmd.Parameters.AddWithValue("?", firstName);
                    cmd.Parameters.AddWithValue("?", mobileNo);
                    cmd.Parameters.AddWithValue("?", nationality);
                    cmd.Parameters.AddWithValue("?", gender);
                    cmd.Parameters.AddWithValue("?", address);
                    cmd.Parameters.AddWithValue("?", Email);
                    cmd.Parameters.AddWithValue("?", checkinDate.ToShortDateString());
                    cmd.Parameters.AddWithValue("?", checkoutDate.ToShortDateString());
                    cmd.Parameters.AddWithValue("?", roomType);
                    cmd.Parameters.AddWithValue("?", paymentMethod);
                    cmd.Parameters.AddWithValue("?", referenceCode);
                    cmd.Parameters.AddWithValue("?", downPayment);
                    cmd.Parameters.AddWithValue("?", totalCost);
                    cmd.ExecuteNonQuery();
                }

                // 2. Delete from CheckedIn table
                string deleteQuery = "DELETE FROM CheckedIn WHERE Id = ?";
                using (OleDbCommand deleteCmd = new OleDbCommand(deleteQuery, con))
                {
                    deleteCmd.Parameters.AddWithValue("?", id);
                    deleteCmd.ExecuteNonQuery();
                }

                string updateRemainingQuery = "UPDATE RoomStatus SET RemainingRooms = RemainingRooms + 1 WHERE RoomTypes = ?";
                string updateStatusQuery = "UPDATE RoomStatus SET [Status] = 'Available' WHERE RoomTypes = ? AND RemainingRooms = 1";

                using (OleDbCommand cmd1 = new OleDbCommand(updateRemainingQuery, con)) // use the 'con' connection instead of 'myConn'
                {
                    cmd1.Parameters.AddWithValue("?", roomType); // Adjust parameter name to match query
                    cmd1.ExecuteNonQuery();
                }

                // Update status if needed
                using (OleDbCommand cmd2 = new OleDbCommand(updateStatusQuery, con)) // use the 'con' connection here too
                {
                    cmd2.Parameters.AddWithValue("?", roomType); // Adjust parameter name to match query
                    cmd2.ExecuteNonQuery();
                }

                con.Close();
            }

            // 4. Remove row from DataGridView
            foreach (DataGridViewRow selectedRow in dgv2.SelectedRows)
            {
                dgv2.Rows.Remove(selectedRow);
            }

            MessageBox.Show("Guest has been checked out successfully.");
            LoadCheckedInData(); // Refresh dgv2

        }



        private void GenerateQRCode(string paymentMethod, double amountDue, string referenceCode = "")
        {
            string qrData = $"Payment for Hotel\nMethod: {paymentMethod}\nAmount: PHP {amountDue:N2}";
            if (!string.IsNullOrWhiteSpace(referenceCode))
                qrData += $"\nReference: {referenceCode}";

            using (QRCodeGenerator qrGenerator = new QRCodeGenerator())
            {
                QRCodeData qrCodeData = qrGenerator.CreateQrCode(qrData, QRCodeGenerator.ECCLevel.Q);
                using (QRCode qrCode = new QRCode(qrCodeData))
                {
                    Bitmap qrImage = qrCode.GetGraphic(20);

                    Form qrForm = new Form()
                    {
                        Text = $"Scan to Pay - {paymentMethod}",
                        Size = new Size(300, 330),
                        StartPosition = FormStartPosition.CenterParent
                    };

                    PictureBox pictureBox = new PictureBox()
                    {
                        Dock = DockStyle.Fill,
                        Image = qrImage,
                        SizeMode = PictureBoxSizeMode.Zoom
                    };

                    qrForm.Controls.Add(pictureBox);
                    qrForm.ShowDialog();
                }
            }
        }




        public void LoadData()
        {
            using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
            {
                con.Open();
                string query = "SELECT * FROM Reservation";
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgv1.DataSource = dt;
                con.Close();
            }
        }
        public void LoadCheckedInData()
        {
            using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
            {
                con.Open();
                string query = "SELECT * FROM CheckedIn";
                OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgv2.DataSource = dt;
                con.Close();
            }
        }

        private void LoadRoomTypes()
        {
            comboBoxRoomType.Items.Clear();
            comboBoxRoomType.Items.Add("All"); // Optional default option

            using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
            {
                con.Open();
                string query = "SELECT DISTINCT RoomType FROM CheckedIn";
                using (OleDbCommand cmd = new OleDbCommand(query, con))
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBoxRoomType.Items.Add(reader["RoomType"].ToString());
                    }
                }
                con.Close();
            }

            comboBoxRoomType.SelectedIndex = 0; // Default to "All"
        }
    
    }
}

