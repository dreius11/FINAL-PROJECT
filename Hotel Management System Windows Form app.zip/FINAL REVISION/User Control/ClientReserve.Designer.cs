﻿namespace FINAL_PROJECT.User_Control
{
    partial class ClientReserve
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControlUser = new TabControl();
            addreserve = new TabPage();
            groupBox1 = new GroupBox();
            totalCostLabel = new Label();
            downpaymentLabel = new Label();
            qrPictureBox = new PictureBox();
            gender = new ComboBox();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label10 = new Label();
            nationality = new TextBox();
            address = new TextBox();
            emailAddress = new TextBox();
            checkin = new DateTimePicker();
            checkout = new DateTimePicker();
            label13 = new Label();
            payment = new ComboBox();
            label2 = new Label();
            label5 = new Label();
            Roomtype = new ComboBox();
            label8 = new Label();
            Add = new Button();
            mobileno = new TextBox();
            label9 = new Label();
            label12 = new Label();
            Fname = new TextBox();
            view = new TabPage();
            addreserveview = new DataGridView();
            tabControlUser.SuspendLayout();
            addreserve.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)qrPictureBox).BeginInit();
            view.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)addreserveview).BeginInit();
            SuspendLayout();
            // 
            // tabControlUser
            // 
            tabControlUser.Alignment = TabAlignment.Bottom;
            tabControlUser.Controls.Add(addreserve);
            tabControlUser.Controls.Add(view);
            tabControlUser.Dock = DockStyle.Fill;
            tabControlUser.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabControlUser.Location = new Point(0, 0);
            tabControlUser.Multiline = true;
            tabControlUser.Name = "tabControlUser";
            tabControlUser.SelectedIndex = 0;
            tabControlUser.Size = new Size(906, 605);
            tabControlUser.TabIndex = 2;
            // 
            // addreserve
            // 
            addreserve.Controls.Add(groupBox1);
            addreserve.Location = new Point(4, 4);
            addreserve.Name = "addreserve";
            addreserve.Padding = new Padding(3);
            addreserve.Size = new Size(898, 571);
            addreserve.TabIndex = 0;
            addreserve.Text = "Add Reservation";
            addreserve.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Teal;
            groupBox1.Controls.Add(totalCostLabel);
            groupBox1.Controls.Add(downpaymentLabel);
            groupBox1.Controls.Add(qrPictureBox);
            groupBox1.Controls.Add(gender);
            groupBox1.Controls.Add(label17);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(nationality);
            groupBox1.Controls.Add(address);
            groupBox1.Controls.Add(emailAddress);
            groupBox1.Controls.Add(checkin);
            groupBox1.Controls.Add(checkout);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(payment);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(Roomtype);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(Add);
            groupBox1.Controls.Add(mobileno);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(Fname);
            groupBox1.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.White;
            groupBox1.ImeMode = ImeMode.NoControl;
            groupBox1.Location = new Point(33, 35);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(833, 501);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Add Reservation";
            // 
            // totalCostLabel
            // 
            totalCostLabel.AutoSize = true;
            totalCostLabel.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            totalCostLabel.Location = new Point(344, 394);
            totalCostLabel.Name = "totalCostLabel";
            totalCostLabel.Size = new Size(20, 25);
            totalCostLabel.TabIndex = 72;
            totalCostLabel.Text = "?";
            // 
            // downpaymentLabel
            // 
            downpaymentLabel.AutoSize = true;
            downpaymentLabel.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            downpaymentLabel.Location = new Point(344, 366);
            downpaymentLabel.Name = "downpaymentLabel";
            downpaymentLabel.Size = new Size(20, 25);
            downpaymentLabel.TabIndex = 70;
            downpaymentLabel.Text = "?";
            // 
            // qrPictureBox
            // 
            qrPictureBox.Location = new Point(648, 331);
            qrPictureBox.Name = "qrPictureBox";
            qrPictureBox.Size = new Size(150, 150);
            qrPictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            qrPictureBox.TabIndex = 69;
            qrPictureBox.TabStop = false;
            // 
            // gender
            // 
            gender.Font = new Font("Nirmala UI", 12F);
            gender.FormattingEnabled = true;
            gender.Items.AddRange(new object[] { "Male", "Female", "Prefer not to say" });
            gender.Location = new Point(324, 273);
            gender.Name = "gender";
            gender.Size = new Size(204, 29);
            gender.TabIndex = 68;
            // 
            // label17
            // 
            label17.Anchor = AnchorStyles.None;
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.White;
            label17.Location = new Point(594, 64);
            label17.Margin = new Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new Size(53, 21);
            label17.TabIndex = 67;
            label17.Text = "Email";
            // 
            // label16
            // 
            label16.Anchor = AnchorStyles.None;
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.White;
            label16.Location = new Point(54, 157);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(70, 21);
            label16.TabIndex = 66;
            label16.Text = "Address";
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.None;
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.White;
            label15.Location = new Point(324, 249);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(65, 21);
            label15.TabIndex = 65;
            label15.Text = "Gender";
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(54, 249);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(97, 21);
            label10.TabIndex = 64;
            label10.Text = "Nationality";
            // 
            // nationality
            // 
            nationality.Font = new Font("Nirmala UI", 12F);
            nationality.Location = new Point(54, 273);
            nationality.Name = "nationality";
            nationality.Size = new Size(204, 29);
            nationality.TabIndex = 63;
            // 
            // address
            // 
            address.Font = new Font("Nirmala UI", 12F);
            address.Location = new Point(54, 181);
            address.Name = "address";
            address.Size = new Size(204, 29);
            address.TabIndex = 62;
            // 
            // emailAddress
            // 
            emailAddress.Font = new Font("Nirmala UI", 12F);
            emailAddress.Location = new Point(594, 88);
            emailAddress.Name = "emailAddress";
            emailAddress.Size = new Size(204, 29);
            emailAddress.TabIndex = 61;
            // 
            // checkin
            // 
            checkin.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkin.Format = DateTimePickerFormat.Short;
            checkin.Location = new Point(324, 181);
            checkin.Name = "checkin";
            checkin.Size = new Size(204, 29);
            checkin.TabIndex = 59;
            // 
            // checkout
            // 
            checkout.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkout.Format = DateTimePickerFormat.Short;
            checkout.Location = new Point(594, 179);
            checkout.Name = "checkout";
            checkout.Size = new Size(204, 29);
            checkout.TabIndex = 58;
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.None;
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.White;
            label13.Location = new Point(54, 338);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(77, 21);
            label13.TabIndex = 57;
            label13.Text = "Payment";
            // 
            // payment
            // 
            payment.Font = new Font("Nirmala UI", 12F);
            payment.FormattingEnabled = true;
            payment.Items.AddRange(new object[] { "Cash", "GCash", "Paymaya", "Banktransfer" });
            payment.Location = new Point(54, 362);
            payment.Name = "payment";
            payment.Size = new Size(204, 29);
            payment.TabIndex = 56;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(594, 155);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(89, 21);
            label2.TabIndex = 55;
            label2.Text = "Check-Out";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(324, 157);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(76, 21);
            label5.TabIndex = 53;
            label5.Text = "Check-In";
            // 
            // Roomtype
            // 
            Roomtype.Font = new Font("Nirmala UI", 12F);
            Roomtype.FormattingEnabled = true;
            Roomtype.Items.AddRange(new object[] { "Standard Room", "Deluxe Room", "Barkada Room", "Family Room" });
            Roomtype.Location = new Point(594, 273);
            Roomtype.Name = "Roomtype";
            Roomtype.Size = new Size(204, 29);
            Roomtype.TabIndex = 51;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(594, 249);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(95, 21);
            label8.TabIndex = 50;
            label8.Text = "Room Type";
            // 
            // Add
            // 
            Add.Anchor = AnchorStyles.None;
            Add.BackColor = Color.White;
            Add.BackgroundImageLayout = ImageLayout.None;
            Add.Cursor = Cursors.Hand;
            Add.FlatAppearance.BorderSize = 0;
            Add.FlatStyle = FlatStyle.Flat;
            Add.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Add.ForeColor = Color.Teal;
            Add.ImageAlign = ContentAlignment.MiddleLeft;
            Add.Location = new Point(72, 449);
            Add.Margin = new Padding(4);
            Add.Name = "Add";
            Add.RightToLeft = RightToLeft.No;
            Add.Size = new Size(158, 32);
            Add.TabIndex = 49;
            Add.Text = "Add";
            Add.TextImageRelation = TextImageRelation.ImageBeforeText;
            Add.UseVisualStyleBackColor = false;
            Add.Click += Add_Click;
            // 
            // mobileno
            // 
            mobileno.Font = new Font("Nirmala UI", 12F);
            mobileno.Location = new Point(324, 88);
            mobileno.Name = "mobileno";
            mobileno.Size = new Size(204, 29);
            mobileno.TabIndex = 2;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(324, 64);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(95, 21);
            label9.TabIndex = 45;
            label9.Text = "Mobile No.";
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.None;
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.White;
            label12.Location = new Point(54, 64);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(56, 21);
            label12.TabIndex = 44;
            label12.Text = "Name";
            // 
            // Fname
            // 
            Fname.Font = new Font("Nirmala UI", 12F);
            Fname.Location = new Point(54, 88);
            Fname.Name = "Fname";
            Fname.Size = new Size(204, 29);
            Fname.TabIndex = 1;
            // 
            // view
            // 
            view.Controls.Add(addreserveview);
            view.Location = new Point(4, 4);
            view.Name = "view";
            view.Padding = new Padding(3);
            view.Size = new Size(898, 571);
            view.TabIndex = 3;
            view.Text = "View Reservation";
            view.UseVisualStyleBackColor = true;
            // 
            // addreserveview
            // 
            addreserveview.AllowUserToAddRows = false;
            addreserveview.AllowUserToDeleteRows = false;
            addreserveview.BackgroundColor = Color.White;
            addreserveview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            addreserveview.Dock = DockStyle.Fill;
            addreserveview.Location = new Point(3, 3);
            addreserveview.Name = "addreserveview";
            addreserveview.ReadOnly = true;
            addreserveview.RowHeadersWidth = 51;
            addreserveview.Size = new Size(892, 565);
            addreserveview.TabIndex = 4;
            // 
            // ClientReserve
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tabControlUser);
            Name = "ClientReserve";
            Size = new Size(906, 605);
            tabControlUser.ResumeLayout(false);
            addreserve.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)qrPictureBox).EndInit();
            view.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)addreserveview).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControlUser;
        private TabPage addreserve;
        private TabPage view;
        private DataGridView addreserveview;
        private GroupBox groupBox1;
        private Label totalCostLabel;
        private Label downpaymentLabel;
        private PictureBox qrPictureBox;
        private ComboBox gender;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label10;
        private TextBox nationality;
        private TextBox address;
        private TextBox emailAddress;
        private DateTimePicker checkin;
        private DateTimePicker checkout;
        private Label label13;
        private ComboBox payment;
        private Label label2;
        private Label label5;
        private ComboBox Roomtype;
        private Label label8;
        private Button Add;
        private TextBox mobileno;
        private Label label9;
        private Label label12;
        private TextBox Fname;
    }
}
