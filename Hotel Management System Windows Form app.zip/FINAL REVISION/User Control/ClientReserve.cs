﻿using iTextSharp.text.pdf;
using MimeKit;
using QRCoder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT.User_Control
{
    public partial class ClientReserve : UserControl
    {
        private OleDbConnection myConn;
        private OleDbDataAdapter da;
        private DataSet ds;


        public ClientReserve()
        {
            InitializeComponent();
            LoadReservationData();
            Roomtype.SelectedIndexChanged += (s, ev) => UpdateCostAndDownpayment();
            checkin.ValueChanged += (s, ev) => UpdateCostAndDownpayment();
            checkout.ValueChanged += (s, ev) => UpdateCostAndDownpayment();

            totalCostLabel.Visible = false;
            downpaymentLabel.Visible = false;
        }

        public event EventHandler ReservationChanged;

        private void OnReservationChanged()
        {
            ReservationChanged?.Invoke(this, EventArgs.Empty);
        }

        public void LoadReservationData()
        {
            try
            {
                myConn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb");

                string query = "SELECT * FROM Reservation";
                da = new OleDbDataAdapter(query, myConn);
                ds = new DataSet();

                myConn.Open();
                da.Fill(ds, "Reservation");
                myConn.Close();

                addreserveview.DataSource = ds.Tables["Reservation"];

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void Add_Click(object sender, EventArgs e)
        {

            try
            {
                // 1. Start Reservation - (User already fills fields on the Form)

                // 2. Validate Inputs
                if (string.IsNullOrWhiteSpace(Fname.Text) ||
                    string.IsNullOrWhiteSpace(mobileno.Text) ||
                    string.IsNullOrWhiteSpace(nationality.Text) ||
                    string.IsNullOrWhiteSpace(gender.Text) ||
                    string.IsNullOrWhiteSpace(address.Text) ||
                    string.IsNullOrWhiteSpace(emailAddress.Text) ||  // Validate Email
                    Roomtype.SelectedIndex == -1 ||
                    payment.SelectedIndex == -1)
                {
                    MessageBox.Show("Please fill in all fields.");
                    return;
                }

                string firstName = Fname.Text.Trim();
                string mobileNo = mobileno.Text.Trim();
                string Nationality = nationality.Text.Trim();
                string Gender = gender.Text.Trim();
                string Address = address.Text.Trim();
                string Email = emailAddress.Text.Trim();  // Store the email from the form
                DateTime checkInDate = checkin.Value.Date;
                DateTime checkOutDate = checkout.Value.Date;
                string roomType = Roomtype.SelectedItem.ToString();
                string paymentMethod = payment.SelectedItem.ToString();

                // Validate dates
                if (checkOutDate < checkInDate)
                {
                    MessageBox.Show("Check-out date cannot be earlier than check-in date.");
                    return;
                }

                // 3. Check if there are available rooms for the selected room type
                using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
                {
                    string checkQuery = "SELECT RemainingRooms FROM RoomStatus WHERE RoomTypes = ?";

                    using (OleDbCommand cmd = new OleDbCommand(checkQuery, myConn))
                    {
                        cmd.Parameters.AddWithValue("@RoomTypes", roomType);

                        myConn.Open();
                        var result = cmd.ExecuteScalar();

                        // Check if there are available rooms
                        if (result == DBNull.Value || Convert.ToInt32(result) <= 0)
                        {
                            MessageBox.Show("Sorry, no available rooms for the selected room type.");
                            return; // Exit if no rooms are available
                        }

                        myConn.Close();
                    }
                }

                // 4. Cost Computation
                decimal totalCost = CalculateTotalCost(roomType, checkInDate, checkOutDate);

                // 5. Confirm Payment/Deposit
                decimal downPayment = totalCost * 0.2m;

                // Generate a random reference number
                Random rand = new Random();
                string referenceCode = rand.Next(100000, 999999).ToString(); // Random number between 100000 and 999999


                switch (paymentMethod)
                {
                    case "GCash":
                        GenerateQRCode($"GCash Payment Completed\nAmount Paid: ₱{downPayment:N2}\nReference: {referenceCode}\nThank you for your payment.");
                        MessageBox.Show($"Please scan the QR code to pay the downpayment using {paymentMethod}.", "Payment Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case "Paymaya":
                        GenerateQRCode($"Paymaya Payment Completed\nAmount Paid: ₱{downPayment:N2}\nReference: {referenceCode}\nThank you for your payment.");
                        MessageBox.Show($"Please scan the QR code to pay the downpayment using {paymentMethod}.", "Payment Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case "Cash":
                        MessageBox.Show($"Please prepare ₱{downPayment:N2} for cash payment.", "Cash Payment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case "Banktransfer":
                        GenerateQRCode($"BankTransfer Payment Completed\nAmount Paid: ₱{downPayment:N2}\nReference: {referenceCode}\nThank you for your payment.");
                        MessageBox.Show($"Please scan the QR code to pay the downpayment using {paymentMethod}", "Payment Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    default:
                        MessageBox.Show("Please select a valid payment method.", "Invalid Payment Method", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                }

                // Ask for Reference Number if Payment Method is GCash or Paymaya
                if (paymentMethod == "GCash" || paymentMethod == "Paymaya" || paymentMethod == "Banktransfer")
                {
                    string referenceNumber = Microsoft.VisualBasic.Interaction.InputBox(
                        "Enter your payment reference number after completing the payment:",
                        "Reference Number Required"
                    );

                    if (string.IsNullOrWhiteSpace(referenceNumber))
                    {
                        MessageBox.Show("You must enter a valid reference number to proceed.", "Missing Reference Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Ensure the inputted reference number is used in the QR code
                    GenerateQRCode($"Payment Completed\nAmount Paid: ₱{downPayment:N2}\nReference: {referenceNumber}\nThank you for your payment.");

                    // Store the reference number
                    referenceCode = referenceNumber; // Ensure the reference code in the database matches this
                }

                // 6. Save to Database with the correct reference number
                using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
                {
                    string query = "INSERT INTO Reservation (FirstName, MobileNo, Nationality, Gender, Address, Email, Checkin, Checkout, RoomType, PaymentMethod, Downpayment, ReferenceCode, TotalCost) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                    {
                        cmd.Parameters.AddWithValue("@FirstName", firstName);
                        cmd.Parameters.AddWithValue("@MobileNo", mobileNo);
                        cmd.Parameters.AddWithValue("@Nationality", Nationality);
                        cmd.Parameters.AddWithValue("@Gender", Gender);
                        cmd.Parameters.AddWithValue("@Address", Address);
                        cmd.Parameters.AddWithValue("@Email", Email);  // Store email instead of IDProof
                        cmd.Parameters.AddWithValue("@Checkin", checkInDate.ToShortDateString());
                        cmd.Parameters.AddWithValue("@Checkout", checkOutDate.ToShortDateString());
                        cmd.Parameters.AddWithValue("@RoomType", roomType);
                        cmd.Parameters.AddWithValue("@PaymentMethod", paymentMethod);
                        cmd.Parameters.AddWithValue("@Downpayment", downPayment);
                        cmd.Parameters.AddWithValue("@ReferenceCode", referenceCode);
                        cmd.Parameters.AddWithValue("@TotalCost", totalCost);

                        myConn.Open();
                        cmd.ExecuteNonQuery();
                        myConn.Close();
                    }
                }

                // 7. Update the RoomStatus table after the reservation is made

                string updateRemainingQuery = "UPDATE RoomStatus SET RemainingRooms = RemainingRooms - 1 WHERE RoomTypes = ?";

                string updateStatusQuery = "UPDATE RoomStatus SET [Status] = 'Unavailable' WHERE RoomTypes = ? AND RemainingRooms = 0";

                using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
                {
                    myConn.Open();

                    // Decrement remaining rooms
                    using (OleDbCommand cmd1 = new OleDbCommand(updateRemainingQuery, myConn))
                    {
                        cmd1.Parameters.AddWithValue("@RoomTypes", roomType);
                        cmd1.ExecuteNonQuery();
                    }

                    // Update status if needed
                    using (OleDbCommand cmd2 = new OleDbCommand(updateStatusQuery, myConn))
                    {
                        cmd2.Parameters.AddWithValue("@RoomTypes", roomType);
                        cmd2.ExecuteNonQuery();
                    }

                    myConn.Close();
                }


                GenerateReceiptPDF(firstName, mobileNo, roomType, checkInDate, checkOutDate, totalCost, downPayment);

                SendEmailNotification(Email, firstName, roomType, checkInDate, checkOutDate, downPayment);
                // 9. Notify User
                MessageBox.Show("Reservation added successfully!");
                qrPictureBox.Visible = false;
                qrPictureBox.Image = null;


                // 10. Reset Form
                OnReservationChanged();
                LoadReservationData();
                ClearFormFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            myConn.Close();
        }


        private void UpdateCostAndDownpayment()
        {
            if (Roomtype.SelectedIndex == -1) return;

            string roomType = Roomtype.SelectedItem.ToString();  // Get the selected room type
            decimal total = CalculateTotalCost(roomType, checkin.Value.Date, checkout.Value.Date);
            decimal down = total * 0.2m;

            totalCostLabel.Text = $"Total Cost: ₱{total:N2}";
            downpaymentLabel.Text = $"Downpayment: ₱{down:N2}";
            totalCostLabel.Visible = true;
            downpaymentLabel.Visible = true;

        }

        private decimal CalculateTotalCost(string roomType, DateTime checkIn, DateTime checkOut)
        {
            int days = (checkOut - checkIn).Days;
            if (days <= 0)
                days = 1; // Minimum of 1 day

            decimal pricePerDay = 0m;

            try
            {
                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb"))
                {
                    string query = "SELECT Price FROM RoomStatus WHERE RoomTypes = ?";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@RoomTypes", roomType);

                        conn.Open();
                        object result = cmd.ExecuteScalar();

                        if (result != null && decimal.TryParse(result.ToString(), out pricePerDay))
                        {
                            // Successfully parsed price
                        }
                        else
                        {
                            MessageBox.Show("Room price not found or invalid for the selected room type.", "Price Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return 0m;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving room price: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0m;
            }

            return days * pricePerDay;
        }



        private void ClearFormFields()
        {
            Fname.Clear();
            mobileno.Clear();
            nationality.Clear();
            Roomtype.SelectedIndex = -1;
            address.Clear();
            emailAddress.Clear();
            gender.SelectedIndex = -1;
            Roomtype.SelectedIndex = -1;
            payment.SelectedIndex = -1;
            checkin.Value = DateTime.Today;
            checkout.Value = DateTime.Today;
            totalCostLabel.Visible = false;
            downpaymentLabel.Visible = false;

        }

        private void GenerateReceiptPDF(string name, string phone, string room, DateTime checkin, DateTime checkout, decimal total, decimal down)
        {
            string receiptsFolder = @"C:\Users\User\Desktop\FINAL REVISION\Receipts";

            if (!Directory.Exists(receiptsFolder))
            {
                Directory.CreateDirectory(receiptsFolder);
            }

            string path = Path.Combine(receiptsFolder, $"Receipt_{name}_{DateTime.Now.Ticks}.pdf");
            iTextSharp.text.Rectangle smallPage = new iTextSharp.text.Rectangle(300f, 421f);
            iTextSharp.text.Document doc = new iTextSharp.text.Document(smallPage);

            // 🛠️ Important: Initialize the PdfWriter here
            PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));

            doc.Open();

            iTextSharp.text.Font titleFont = iTextSharp.text.FontFactory.GetFont(iTextSharp.text.FontFactory.HELVETICA_BOLD, 18);
            iTextSharp.text.Paragraph title = new iTextSharp.text.Paragraph("Hotel Reservation Receipt", titleFont)
            {
                Alignment = iTextSharp.text.Element.ALIGN_CENTER
            };
            doc.Add(title);

            doc.Add(new iTextSharp.text.Paragraph("\n"));

            iTextSharp.text.pdf.PdfPTable table = new iTextSharp.text.pdf.PdfPTable(2)
            {
                WidthPercentage = 100
            };
            table.SetWidths(new float[] { 1.9f, 2f });

            table.AddCell("Guest Name:");
            table.AddCell(name);
            table.AddCell("Phone Number:");
            table.AddCell(phone);
            table.AddCell("Room Type:");
            table.AddCell(room);
            table.AddCell("Check-in Date:");
            table.AddCell(checkin.ToShortDateString());
            table.AddCell("Check-out Date:");
            table.AddCell(checkout.ToShortDateString());
            table.AddCell("Total Cost:");
            table.AddCell($"₱{total:N2}");
            table.AddCell("Downpayment:");
            table.AddCell($"₱{down:N2}");

            doc.Add(table);

            doc.Add(new iTextSharp.text.Paragraph("\n"));

            iTextSharp.text.Font footerFont = iTextSharp.text.FontFactory.GetFont(iTextSharp.text.FontFactory.HELVETICA, 10, iTextSharp.text.Font.ITALIC);
            iTextSharp.text.Paragraph footer = new iTextSharp.text.Paragraph("Thank you for your reservation!", footerFont)
            {
                Alignment = iTextSharp.text.Element.ALIGN_CENTER
            };
            doc.Add(footer);

            doc.Close();
        }




        private void GenerateQRCode(string content)
        {
            // Create the QR code
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(content, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            // Assign the same image to both PictureBoxes
            qrPictureBox.Image = qrCodeImage;
            qrPictureBox.Visible = true;
        }



        private void SendEmailNotification(string email, string firstName, string roomType, DateTime checkInDate, DateTime checkOutDate, decimal downPayment)
        {
            try
            {
                var emailMessage = new MimeMessage();
                emailMessage.From.Add(new MailboxAddress("Your Hotel", "your-email@example.com"));
                emailMessage.To.Add(new MailboxAddress(firstName, email));
                emailMessage.Subject = "Reservation Confirmation";

                var bodyBuilder = new BodyBuilder
                {
                    TextBody = $"Dear {firstName},\n\n" +
                "We are pleased to inform you that your reservation has been confirmed!\n\n" +
                "Here are the details of your booking:\n\n" +
                $"Name: {firstName}\n" +
                $"Room Type: {roomType}\n" +
                $"Check-in Date: {checkInDate.ToShortDateString()}\n" +
                $"Check-out Date: {checkOutDate.ToShortDateString()}\n\n" +
                $"Total Downpayment: ₱{downPayment:N2}\n\n" +
                "Please note:\n" +
                "- Check-in time starts at 2:00 PM\n" +
                "- Check-out time is until 12:00 NN\n" +
                "- This reservation is *NON-REFUNDABLE* and cannot be canceled\n\n" +
                "For any changes to your reservation or further assistance, please feel free to contact us.\n\n" +
                "Thank you for choosing us. We look forward to welcoming you soon!\n\n" +
                "Best regards,\n" +
                "Reservations Team\n"
                };
                emailMessage.Body = bodyBuilder.ToMessageBody();


                using (var client = new MailKit.Net.Smtp.SmtpClient())
                {
                    client.Connect("smtp.gmail.com", 587, false);  // Replace with your SMTP server settings
                    client.Authenticate("karlrosos467@gmail.com", "hvfj erkq ebru qjqo");  // Your email and password
                    client.Send(emailMessage);
                    client.Disconnect(true);
                }

                MessageBox.Show("Confirmation email sent successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending email: " + ex.Message);
            }
        }


    }
}
