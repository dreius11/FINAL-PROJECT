﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT.User_Control
{
    public partial class Clientdashboard : UserControl
    {
        public Clientdashboard()
        {
            InitializeComponent();
            this.Load += load;
        }
        private void load(object sender, EventArgs e)
        {

        }
    }
}
