﻿namespace FINAL_PROJECT
{
    partial class EmployeeUser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControlUser = new TabControl();
            addemployee = new TabPage();
            addnameemployee = new GroupBox();
            label1 = new Label();
            Position = new TextBox();
            btnadd = new Button();
            Lname = new TextBox();
            label = new Label();
            label2 = new Label();
            Fname = new TextBox();
            dataGridView1 = new DataGridView();
            tabPage2 = new TabPage();
            dataGridView2 = new DataGridView();
            updateemployee = new GroupBox();
            label3 = new Label();
            uptPosition = new TextBox();
            btnupdate = new Button();
            button3 = new Button();
            uptLname = new TextBox();
            label6 = new Label();
            label7 = new Label();
            uptFname = new TextBox();
            tabPage3 = new TabPage();
            groupBox1 = new GroupBox();
            button2 = new Button();
            textBox4 = new TextBox();
            label4 = new Label();
            label5 = new Label();
            textBox5 = new TextBox();
            dataGridView3 = new DataGridView();
            tabControlUser.SuspendLayout();
            addemployee.SuspendLayout();
            addnameemployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            updateemployee.SuspendLayout();
            tabPage3.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            SuspendLayout();
            // 
            // tabControlUser
            // 
            tabControlUser.Alignment = TabAlignment.Bottom;
            tabControlUser.Controls.Add(addemployee);
            tabControlUser.Controls.Add(tabPage2);
            tabControlUser.Controls.Add(tabPage3);
            tabControlUser.Dock = DockStyle.Fill;
            tabControlUser.Location = new Point(0, 0);
            tabControlUser.Multiline = true;
            tabControlUser.Name = "tabControlUser";
            tabControlUser.SelectedIndex = 0;
            tabControlUser.Size = new Size(906, 605);
            tabControlUser.TabIndex = 0;
            // 
            // addemployee
            // 
            addemployee.Controls.Add(addnameemployee);
            addemployee.Controls.Add(dataGridView1);
            addemployee.Location = new Point(4, 4);
            addemployee.Name = "addemployee";
            addemployee.Padding = new Padding(3);
            addemployee.Size = new Size(898, 571);
            addemployee.TabIndex = 0;
            addemployee.Text = "Add Employee";
            addemployee.UseVisualStyleBackColor = true;
            // 
            // addnameemployee
            // 
            addnameemployee.BackColor = Color.Teal;
            addnameemployee.Controls.Add(label1);
            addnameemployee.Controls.Add(Position);
            addnameemployee.Controls.Add(btnadd);
            addnameemployee.Controls.Add(Lname);
            addnameemployee.Controls.Add(label);
            addnameemployee.Controls.Add(label2);
            addnameemployee.Controls.Add(Fname);
            addnameemployee.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addnameemployee.ForeColor = Color.White;
            addnameemployee.Location = new Point(28, 28);
            addnameemployee.Name = "addnameemployee";
            addnameemployee.Size = new Size(232, 397);
            addnameemployee.TabIndex = 2;
            addnameemployee.TabStop = false;
            addnameemployee.Text = "Add Employee";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(10, 254);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(72, 21);
            label1.TabIndex = 48;
            label1.Text = "Position";
            // 
            // Position
            // 
            Position.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Position.Location = new Point(10, 278);
            Position.Name = "Position";
            Position.Size = new Size(204, 29);
            Position.TabIndex = 47;
            // 
            // btnadd
            // 
            btnadd.Anchor = AnchorStyles.None;
            btnadd.BackColor = Color.White;
            btnadd.BackgroundImageLayout = ImageLayout.None;
            btnadd.Cursor = Cursors.Hand;
            btnadd.FlatAppearance.BorderSize = 0;
            btnadd.FlatStyle = FlatStyle.Flat;
            btnadd.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnadd.ForeColor = Color.Teal;
            btnadd.ImageAlign = ContentAlignment.MiddleLeft;
            btnadd.Location = new Point(62, 341);
            btnadd.Margin = new Padding(4);
            btnadd.Name = "btnadd";
            btnadd.RightToLeft = RightToLeft.No;
            btnadd.Size = new Size(100, 28);
            btnadd.TabIndex = 46;
            btnadd.Text = "Add";
            btnadd.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnadd.UseVisualStyleBackColor = false;
            btnadd.Click += btnadd_Click;
            // 
            // Lname
            // 
            Lname.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Lname.Location = new Point(12, 187);
            Lname.Name = "Lname";
            Lname.Size = new Size(204, 29);
            Lname.TabIndex = 2;
            // 
            // label
            // 
            label.Anchor = AnchorStyles.None;
            label.AutoSize = true;
            label.BackColor = Color.Transparent;
            label.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label.ForeColor = Color.White;
            label.Location = new Point(12, 163);
            label.Margin = new Padding(4, 0, 4, 0);
            label.Name = "label";
            label.Size = new Size(90, 21);
            label.TabIndex = 45;
            label.Text = "Last Name";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(10, 72);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(92, 21);
            label2.TabIndex = 44;
            label2.Text = "First Name";
            // 
            // Fname
            // 
            Fname.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Fname.Location = new Point(10, 96);
            Fname.Name = "Fname";
            Fname.Size = new Size(204, 29);
            Fname.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(266, 6);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(626, 559);
            dataGridView1.TabIndex = 3;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(dataGridView2);
            tabPage2.Controls.Add(updateemployee);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(898, 571);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Update Employee";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(266, 6);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.Size = new Size(626, 559);
            dataGridView2.TabIndex = 3;
            // 
            // updateemployee
            // 
            updateemployee.Controls.Add(label3);
            updateemployee.Controls.Add(uptPosition);
            updateemployee.Controls.Add(btnupdate);
            updateemployee.Controls.Add(button3);
            updateemployee.Controls.Add(uptLname);
            updateemployee.Controls.Add(label6);
            updateemployee.Controls.Add(label7);
            updateemployee.Controls.Add(uptFname);
            updateemployee.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            updateemployee.ForeColor = Color.Teal;
            updateemployee.ImeMode = ImeMode.NoControl;
            updateemployee.Location = new Point(28, 28);
            updateemployee.Name = "updateemployee";
            updateemployee.Size = new Size(232, 397);
            updateemployee.TabIndex = 2;
            updateemployee.TabStop = false;
            updateemployee.Text = "Update Employee";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Teal;
            label3.Location = new Point(10, 163);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(90, 21);
            label3.TabIndex = 51;
            label3.Text = "Last Name";
            // 
            // uptPosition
            // 
            uptPosition.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            uptPosition.Location = new Point(10, 278);
            uptPosition.Name = "uptPosition";
            uptPosition.Size = new Size(204, 29);
            uptPosition.TabIndex = 50;
            // 
            // btnupdate
            // 
            btnupdate.Anchor = AnchorStyles.None;
            btnupdate.BackColor = Color.Teal;
            btnupdate.BackgroundImageLayout = ImageLayout.None;
            btnupdate.Cursor = Cursors.Hand;
            btnupdate.FlatAppearance.BorderSize = 0;
            btnupdate.FlatStyle = FlatStyle.Flat;
            btnupdate.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnupdate.ForeColor = Color.White;
            btnupdate.ImageAlign = ContentAlignment.MiddleLeft;
            btnupdate.Location = new Point(62, 341);
            btnupdate.Margin = new Padding(4);
            btnupdate.Name = "btnupdate";
            btnupdate.RightToLeft = RightToLeft.No;
            btnupdate.Size = new Size(100, 28);
            btnupdate.TabIndex = 49;
            btnupdate.Text = "Update";
            btnupdate.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnupdate.UseVisualStyleBackColor = false;
            btnupdate.Click += btnupdate_Click_1;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.None;
            button3.BackColor = Color.FromArgb(37, 198, 218);
            button3.BackgroundImageLayout = ImageLayout.None;
            button3.Cursor = Cursors.Hand;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(116, 668);
            button3.Margin = new Padding(4);
            button3.Name = "button3";
            button3.RightToLeft = RightToLeft.No;
            button3.Size = new Size(100, 28);
            button3.TabIndex = 47;
            button3.Text = "ADD";
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = false;
            // 
            // uptLname
            // 
            uptLname.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            uptLname.Location = new Point(10, 187);
            uptLname.Name = "uptLname";
            uptLname.Size = new Size(204, 29);
            uptLname.TabIndex = 2;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Teal;
            label6.Location = new Point(12, 254);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(72, 21);
            label6.TabIndex = 45;
            label6.Text = "Position";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Teal;
            label7.Location = new Point(10, 72);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(92, 21);
            label7.TabIndex = 44;
            label7.Text = "First Name";
            // 
            // uptFname
            // 
            uptFname.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            uptFname.Location = new Point(10, 96);
            uptFname.Name = "uptFname";
            uptFname.Size = new Size(204, 29);
            uptFname.TabIndex = 1;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(groupBox1);
            tabPage3.Controls.Add(dataGridView3);
            tabPage3.Location = new Point(4, 4);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(898, 571);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Delete Employee";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Teal;
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(28, 28);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(232, 397);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Delete Employee";
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.None;
            button2.BackColor = Color.White;
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Teal;
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(54, 306);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.RightToLeft = RightToLeft.No;
            button2.Size = new Size(100, 28);
            button2.TabIndex = 46;
            button2.Text = "Delete";
            button2.TextImageRelation = TextImageRelation.ImageBeforeText;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(10, 230);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(204, 29);
            textBox4.TabIndex = 2;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(12, 206);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(90, 21);
            label4.TabIndex = 45;
            label4.Text = "Last Name";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(10, 115);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(92, 21);
            label5.TabIndex = 44;
            label5.Text = "First Name";
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox5.Location = new Point(10, 139);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(204, 29);
            textBox5.TabIndex = 1;
            // 
            // dataGridView3
            // 
            dataGridView3.AllowUserToAddRows = false;
            dataGridView3.AllowUserToDeleteRows = false;
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(266, 6);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.ReadOnly = true;
            dataGridView3.Size = new Size(626, 559);
            dataGridView3.TabIndex = 3;
            // 
            // EmployeeUser
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tabControlUser);
            Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "EmployeeUser";
            Size = new Size(906, 605);
            tabControlUser.ResumeLayout(false);
            addemployee.ResumeLayout(false);
            addnameemployee.ResumeLayout(false);
            addnameemployee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            updateemployee.ResumeLayout(false);
            updateemployee.PerformLayout();
            tabPage3.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControlUser;
        private TabPage addemployee;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private GroupBox addnameemployee;
        private Button btnadd;
        private TextBox Lname;
        private Label label;
        private Label label2;
        private TextBox Fname;
        private DataGridView dataGridView1;
        private GroupBox groupBox1;
        private Button button2;
        private TextBox textBox4;
        private Label label4;
        private Label label5;
        private TextBox textBox5;
        private DataGridView dataGridView3;
        private DataGridView dataGridView2;
        private GroupBox updateemployee;
        private Button btnupdate;
        private Button button3;
        private TextBox uptLname;
        private Label label6;
        private Label label7;
        private TextBox uptFname;
        private Label label1;
        private TextBox Position;
        private Label label3;
        private TextBox uptPosition;
    }
}
