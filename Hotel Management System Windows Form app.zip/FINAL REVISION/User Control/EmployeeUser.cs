﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT
{
    public partial class EmployeeUser : UserControl
    {
        private OleDbConnection myConn;
        private OleDbDataAdapter da;
        private DataSet ds;

        public EmployeeUser()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            try
            {
                myConn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb");

                // Modify query to select data from Employee table
                string query = "SELECT * FROM Employee";

                da = new OleDbDataAdapter(query, myConn);

                ds = new DataSet();
                myConn.Open();
                da.Fill(ds, "Employee");

                // Bind the DataGridViews to the Employee table
                dataGridView1.DataSource = ds.Tables["Employee"];
                dataGridView2.DataSource = ds.Tables["Employee"];
                dataGridView3.DataSource = ds.Tables["Employee"];

                myConn.Close();

                // Style the DataGridViews
                StyleDataGridView(dataGridView1);
                StyleDataGridView(dataGridView2);
                StyleDataGridView(dataGridView3);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void StyleDataGridView(DataGridView dgv)
        {
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Teal;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.EnableHeadersVisualStyles = false;
            dgv.RowTemplate.Height = 30;
            dgv.RowHeadersVisible = true;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.LightGray;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            dgv.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;
        }



        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate required fields (FirstName, LastName, and Position)
                if (string.IsNullOrEmpty(Fname.Text) || string.IsNullOrEmpty(Lname.Text) || string.IsNullOrEmpty(Position.Text))
                {
                    MessageBox.Show("Please fill in all fields (First Name, Last Name, and Position).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Get values from input fields
                string firstName = Fname.Text.Trim();
                string lastName = Lname.Text.Trim();
                string position = Position.Text.Trim(); // Assuming Position is the name of your TextBox for the Position field

                // Database connection string
                string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb";

                string query = "INSERT INTO Employee ([FirstName], [LastName], [Position]) VALUES (?, ?, ?)";

                using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                {
                    cmd.Parameters.AddWithValue("?", firstName);
                    cmd.Parameters.AddWithValue("?", lastName);
                    cmd.Parameters.AddWithValue("?", position);

                    myConn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    myConn.Close();



                    // Show success or failure message
                    if (rowsAffected > 0)
                    {

                        LoadData();

                        // Show confirmation message
                        MessageBox.Show("Employee added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("No data was inserted. Check your database.", "Insert Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnupdate_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Ensure an employee is selected for updating
                if (dataGridView2.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select an employee to update.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Get values from the selected row
                int ID = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["Id"].Value);
                string firstName = uptFname.Text.Trim();
                string lastName = uptLname.Text.Trim();
                string position = uptPosition.Text.Trim();

                // Ensure all fields are filled in
                if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(position))
                {
                    MessageBox.Show("Please fill in all fields (First Name, Last Name, and Position).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Confirm update
                DialogResult result = MessageBox.Show($"Are you sure you want to update {firstName} {lastName}?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                if (result == DialogResult.Yes)
                {   
                    string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb";
                    string query = "UPDATE Employee SET [FirstName] = ?, [LastName] = ?, [Position] = ? WHERE [Id] = ?";

                    using (OleDbConnection myConn = new OleDbConnection(connString))
                    {
                        using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                        {
                            // Add parameters in the correct order
                            cmd.Parameters.AddWithValue("?", firstName);
                            cmd.Parameters.AddWithValue("?", lastName);
                            cmd.Parameters.AddWithValue("?", position);
                            cmd.Parameters.AddWithValue("?", ID); // ID is used for the WHERE clause

                            myConn.Open();
                            int rowsAffected = cmd.ExecuteNonQuery();
                            myConn.Close();

                            // Show success or failure message
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Employee updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadData(); // Refresh the grid to reflect the changes
                            }
                            else
                            {
                                MessageBox.Show("No record found to update.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView3.SelectedRows.Count == 0 || dataGridView3.CurrentRow == null)
                {
                    MessageBox.Show("Please select an employee to delete.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int ID = Convert.ToInt32(dataGridView3.SelectedRows[0].Cells["Id"].Value);

                // 🔹 Get FirstName and LastName from selected row
                string firstName = dataGridView3.SelectedRows[0].Cells["FirstName"].Value.ToString();
                string lastName = dataGridView3.SelectedRows[0].Cells["LastName"].Value.ToString();

                // 🔹 Confirm deletion
                DialogResult result = MessageBox.Show($"Are you sure you want to delete {firstName} {lastName}?",
                                                      "Confirm Deletion",
                                                      MessageBoxButtons.YesNo,
                                                      MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb";
                    string query = "DELETE FROM Employee WHERE [FirstName] = ? AND [LastName] = ?";

                    using (OleDbConnection myConn = new OleDbConnection(connString))
                    {
                        using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                        {
                            cmd.Parameters.AddWithValue("?", firstName);
                            cmd.Parameters.AddWithValue("?", lastName);

                            myConn.Open();
                            int rowsAffected = cmd.ExecuteNonQuery();
                            myConn.Close();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Employee deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadData(); // Refresh the grid
                            }
                            else
                            {
                                MessageBox.Show("No record found to delete.", "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

