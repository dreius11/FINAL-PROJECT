﻿namespace FINAL_PROJECT.User_Control
{
    partial class RoomStatus
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RoomStatus));
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            label3 = new Label();
            remainingroomsTextBox = new TextBox();
            Price = new Label();
            priceTextBox = new TextBox();
            roomstat = new ComboBox();
            button1 = new Button();
            label2 = new Label();
            label1 = new Label();
            UpdateRoomDGV = new DataGridView();
            norooms = new TextBox();
            pictureBox1 = new PictureBox();
            tabPage2 = new TabPage();
            viewRoom1 = new ViewRoom();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)UpdateRoomDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(906, 605);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(remainingroomsTextBox);
            tabPage1.Controls.Add(Price);
            tabPage1.Controls.Add(priceTextBox);
            tabPage1.Controls.Add(roomstat);
            tabPage1.Controls.Add(button1);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(UpdateRoomDGV);
            tabPage1.Controls.Add(norooms);
            tabPage1.Controls.Add(pictureBox1);
            tabPage1.Location = new Point(4, 4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(898, 571);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "UPDATE ROOMS";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            label3.ForeColor = Color.Teal;
            label3.Location = new Point(57, 223);
            label3.Name = "label3";
            label3.Size = new Size(149, 21);
            label3.TabIndex = 17;
            label3.Text = "Remaining Rooms";
            label3.TextAlign = ContentAlignment.TopRight;
            // 
            // remainingroomsTextBox
            // 
            remainingroomsTextBox.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            remainingroomsTextBox.Location = new Point(57, 247);
            remainingroomsTextBox.Name = "remainingroomsTextBox";
            remainingroomsTextBox.Size = new Size(197, 29);
            remainingroomsTextBox.TabIndex = 16;
            // 
            // Price
            // 
            Price.AutoSize = true;
            Price.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            Price.ForeColor = Color.Teal;
            Price.Location = new Point(57, 300);
            Price.Name = "Price";
            Price.Size = new Size(48, 21);
            Price.TabIndex = 15;
            Price.Text = "Price";
            Price.TextAlign = ContentAlignment.TopRight;
            // 
            // priceTextBox
            // 
            priceTextBox.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            priceTextBox.Location = new Point(57, 324);
            priceTextBox.Name = "priceTextBox";
            priceTextBox.Size = new Size(197, 29);
            priceTextBox.TabIndex = 14;
            // 
            // roomstat
            // 
            roomstat.FormattingEnabled = true;
            roomstat.Items.AddRange(new object[] { "Available", "Full", "Under Maintenance" });
            roomstat.Location = new Point(57, 401);
            roomstat.Name = "roomstat";
            roomstat.Size = new Size(197, 29);
            roomstat.TabIndex = 13;
            // 
            // button1
            // 
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Teal;
            button1.Location = new Point(94, 445);
            button1.Name = "button1";
            button1.Size = new Size(121, 32);
            button1.TabIndex = 12;
            button1.Text = "Update";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            label2.ForeColor = Color.Teal;
            label2.Location = new Point(57, 377);
            label2.Name = "label2";
            label2.Size = new Size(105, 21);
            label2.TabIndex = 8;
            label2.Text = "Room Status";
            label2.TextAlign = ContentAlignment.TopRight;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold);
            label1.ForeColor = Color.Teal;
            label1.Location = new Point(57, 146);
            label1.Name = "label1";
            label1.Size = new Size(149, 21);
            label1.TabIndex = 7;
            label1.Text = "Number of Rooms";
            label1.TextAlign = ContentAlignment.TopRight;
            // 
            // UpdateRoomDGV
            // 
            UpdateRoomDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            UpdateRoomDGV.Location = new Point(304, 32);
            UpdateRoomDGV.Name = "UpdateRoomDGV";
            UpdateRoomDGV.Size = new Size(569, 511);
            UpdateRoomDGV.TabIndex = 6;
            // 
            // norooms
            // 
            norooms.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            norooms.Location = new Point(57, 170);
            norooms.Name = "norooms";
            norooms.Size = new Size(197, 29);
            norooms.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(892, 565);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(viewRoom1);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(192, 66);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "VIEW ROOMS";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // viewRoom1
            // 
            viewRoom1.BackColor = Color.White;
            viewRoom1.Dock = DockStyle.Fill;
            viewRoom1.Location = new Point(3, 3);
            viewRoom1.Name = "viewRoom1";
            viewRoom1.Size = new Size(186, 60);
            viewRoom1.TabIndex = 0;
            // 
            // RoomStatus
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tabControl1);
            Name = "RoomStatus";
            Size = new Size(906, 605);
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)UpdateRoomDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPage2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TextBox norooms;
        private PictureBox pictureBox1;
        private ViewRoom viewRoom1;
        private Button button1;
        private Label label2;
        private Label label1;
        private DataGridView UpdateRoomDGV;
        private ComboBox roomstat;
        private Label Price;
        private TextBox priceTextBox;
        private Label label3;
        private TextBox remainingroomsTextBox;
    }
}
