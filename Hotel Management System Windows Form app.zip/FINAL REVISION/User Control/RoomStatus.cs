﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT.User_Control
{
    public partial class RoomStatus : UserControl
    {
        private OleDbConnection myConn;
        private OleDbDataAdapter da;
        private DataSet ds;

        public RoomStatus()
        {
            InitializeComponent();
            LoadRoomData();

        }
        private void RoomStatus_Load(object sender, EventArgs e)
        {
            LoadRoomData(); // ✅ Just call your safe method here
        }

        public void LoadRoomData()
        {
            try
            {
                myConn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb");
                string query = "SELECT * FROM RoomStatus";
                da = new OleDbDataAdapter(query, myConn);
                ds = new DataSet();

                myConn.Open();
                da.Fill(ds, "RoomStatus");
                myConn.Close();

                UpdateRoomDGV.DataSource = ds.Tables["RoomStatus"];
                StyleDataGridView(UpdateRoomDGV);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void StyleDataGridView(DataGridView dgv)
        {
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 10, FontStyle.Bold);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Teal;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.EnableHeadersVisualStyles = false;
            dgv.RowTemplate.Height = 30;
            dgv.RowHeadersVisible = true;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.White;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 10);
            dgv.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(norooms.Text) ||
                    roomstat.SelectedIndex == -1 ||
                    string.IsNullOrWhiteSpace(priceTextBox.Text) ||
                    string.IsNullOrWhiteSpace(remainingroomsTextBox.Text))
                {
                    MessageBox.Show("Please fill in all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string TotalRooms = norooms.Text.Trim();
                string RoomStatus = roomstat.SelectedItem.ToString();
                string Price = priceTextBox.Text.Trim();
                string RemainingRooms = remainingroomsTextBox.Text.Trim();

                if (UpdateRoomDGV.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a room to update.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int RoomID = Convert.ToInt32(UpdateRoomDGV.SelectedRows[0].Cells["RoomID"].Value);

                using (OleDbConnection myConn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb"))
                {
                    string query = "UPDATE RoomStatus SET TotalRooms = ?, Status = ?, Price = ?, RemainingRooms = ? WHERE RoomID = ?";

                    using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                    {
                        cmd.Parameters.AddWithValue("@TotalRooms", TotalRooms);
                        cmd.Parameters.AddWithValue("@Status", RoomStatus);
                        cmd.Parameters.AddWithValue("@Price", Price);
                        cmd.Parameters.AddWithValue("@RemainingRooms", RemainingRooms);
                        cmd.Parameters.AddWithValue("@RoomID", RoomID);

                        myConn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        myConn.Close();

                        if (rowsAffected > 0)
                        {
                            LoadRoomData();

                            norooms.Text = "";
                            roomstat.SelectedIndex = -1;
                            priceTextBox.Text = "";
                            remainingroomsTextBox.Text = "";

                            MessageBox.Show("Room status updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Update failed. Please try again.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

  
    }
}
