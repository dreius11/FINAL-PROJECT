﻿namespace FINAL_PROJECT.User_Control
{
    partial class ViewRoom
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewRoom));
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            flowLayoutPanel1 = new FlowLayoutPanel();
            labelstandard = new Label();
            lblStandard = new Label();
            label2 = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            button2 = new Button();
            panel3 = new Panel();
            pictureBox3 = new PictureBox();
            button3 = new Button();
            panel4 = new Panel();
            pictureBox4 = new PictureBox();
            button4 = new Button();
            flowLayoutPanel2 = new FlowLayoutPanel();
            labeldeluxe = new Label();
            lblDeluxe = new Label();
            label6 = new Label();
            flowLayoutPanel3 = new FlowLayoutPanel();
            labelbarkada = new Label();
            lblBarkada = new Label();
            label9 = new Label();
            flowLayoutPanel4 = new FlowLayoutPanel();
            labelfamily = new Label();
            lblFamily = new Label();
            label12 = new Label();
            pictureBox5 = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            timer3 = new System.Windows.Forms.Timer(components);
            timer4 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            flowLayoutPanel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            flowLayoutPanel2.SuspendLayout();
            flowLayoutPanel3.SuspendLayout();
            flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackgroundImageLayout = ImageLayout.Stretch;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(button1);
            panel1.Location = new Point(89, 47);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(343, 300);
            panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(343, 247);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.White;
            button1.Dock = DockStyle.Bottom;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold);
            button1.ForeColor = Color.Teal;
            button1.Location = new Point(0, 247);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(343, 53);
            button1.TabIndex = 0;
            button1.Text = "Standard Room";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(labelstandard);
            flowLayoutPanel1.Controls.Add(lblStandard);
            flowLayoutPanel1.Controls.Add(label2);
            flowLayoutPanel1.Location = new Point(434, 47);
            flowLayoutPanel1.Margin = new Padding(3, 4, 3, 4);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(0, 300);
            flowLayoutPanel1.TabIndex = 2;
            // 
            // labelstandard
            // 
            labelstandard.AutoSize = true;
            labelstandard.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelstandard.Location = new Point(3, 0);
            labelstandard.Name = "labelstandard";
            labelstandard.Size = new Size(188, 37);
            labelstandard.TabIndex = 0;
            labelstandard.Text = "Price : ₱1000";
            // 
            // lblStandard
            // 
            lblStandard.AutoSize = true;
            lblStandard.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblStandard.Location = new Point(3, 37);
            lblStandard.Name = "lblStandard";
            lblStandard.Size = new Size(78, 32);
            lblStandard.TabIndex = 2;
            lblStandard.Text = "label3";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(3, 69);
            label2.Name = "label2";
            label2.Size = new Size(447, 224);
            label2.TabIndex = 1;
            label2.Text = resources.GetString("label2.Text");
            // 
            // panel2
            // 
            panel2.Controls.Add(pictureBox2);
            panel2.Controls.Add(button2);
            panel2.Location = new Point(598, 47);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(343, 300);
            panel2.TabIndex = 1;
            // 
            // pictureBox2
            // 
            pictureBox2.Dock = DockStyle.Fill;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Margin = new Padding(3, 4, 3, 4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(343, 247);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Teal;
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Dock = DockStyle.Bottom;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(0, 247);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(343, 53);
            button2.TabIndex = 1;
            button2.Text = "Deluxe Room";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox3);
            panel3.Controls.Add(button3);
            panel3.Location = new Point(89, 397);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(343, 300);
            panel3.TabIndex = 1;
            // 
            // pictureBox3
            // 
            pictureBox3.Dock = DockStyle.Fill;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(0, 0);
            pictureBox3.Margin = new Padding(3, 4, 3, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(343, 247);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Teal;
            button3.BackgroundImageLayout = ImageLayout.None;
            button3.Dock = DockStyle.Bottom;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Location = new Point(0, 247);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(343, 53);
            button3.TabIndex = 1;
            button3.Text = "Barkada Room";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // panel4
            // 
            panel4.Controls.Add(pictureBox4);
            panel4.Controls.Add(button4);
            panel4.Location = new Point(598, 397);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(343, 300);
            panel4.TabIndex = 1;
            // 
            // pictureBox4
            // 
            pictureBox4.Dock = DockStyle.Fill;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(0, 0);
            pictureBox4.Margin = new Padding(3, 4, 3, 4);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(343, 247);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 2;
            pictureBox4.TabStop = false;
            // 
            // button4
            // 
            button4.BackColor = Color.White;
            button4.Dock = DockStyle.Bottom;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold);
            button4.ForeColor = Color.Teal;
            button4.Location = new Point(0, 247);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(343, 53);
            button4.TabIndex = 1;
            button4.Text = "Family Room";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Controls.Add(labeldeluxe);
            flowLayoutPanel2.Controls.Add(lblDeluxe);
            flowLayoutPanel2.Controls.Add(label6);
            flowLayoutPanel2.Location = new Point(89, 47);
            flowLayoutPanel2.Margin = new Padding(3, 4, 3, 4);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(0, 300);
            flowLayoutPanel2.TabIndex = 3;
            // 
            // labeldeluxe
            // 
            labeldeluxe.AutoSize = true;
            labeldeluxe.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labeldeluxe.Location = new Point(3, 0);
            labeldeluxe.Name = "labeldeluxe";
            labeldeluxe.Size = new Size(188, 37);
            labeldeluxe.TabIndex = 0;
            labeldeluxe.Text = "Price : ₱2000";
            // 
            // lblDeluxe
            // 
            lblDeluxe.AutoSize = true;
            lblDeluxe.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDeluxe.Location = new Point(3, 37);
            lblDeluxe.Name = "lblDeluxe";
            lblDeluxe.Size = new Size(78, 32);
            lblDeluxe.TabIndex = 2;
            lblDeluxe.Text = "label5";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(3, 69);
            label6.Name = "label6";
            label6.Size = new Size(480, 252);
            label6.TabIndex = 1;
            label6.Text = resources.GetString("label6.Text");
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.Controls.Add(labelbarkada);
            flowLayoutPanel3.Controls.Add(lblBarkada);
            flowLayoutPanel3.Controls.Add(label9);
            flowLayoutPanel3.Location = new Point(434, 397);
            flowLayoutPanel3.Margin = new Padding(3, 4, 3, 4);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(0, 300);
            flowLayoutPanel3.TabIndex = 3;
            // 
            // labelbarkada
            // 
            labelbarkada.AutoSize = true;
            labelbarkada.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelbarkada.Location = new Point(3, 0);
            labelbarkada.Name = "labelbarkada";
            labelbarkada.Size = new Size(188, 37);
            labelbarkada.TabIndex = 0;
            labelbarkada.Text = "Price : ₱3600";
            // 
            // lblBarkada
            // 
            lblBarkada.AutoSize = true;
            lblBarkada.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblBarkada.Location = new Point(3, 37);
            lblBarkada.Name = "lblBarkada";
            lblBarkada.Size = new Size(78, 32);
            lblBarkada.TabIndex = 2;
            lblBarkada.Text = "label8";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(3, 69);
            label9.Name = "label9";
            label9.Size = new Size(403, 224);
            label9.TabIndex = 1;
            label9.Text = resources.GetString("label9.Text");
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.Controls.Add(labelfamily);
            flowLayoutPanel4.Controls.Add(lblFamily);
            flowLayoutPanel4.Controls.Add(label12);
            flowLayoutPanel4.Location = new Point(89, 397);
            flowLayoutPanel4.Margin = new Padding(3, 4, 3, 4);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(0, 300);
            flowLayoutPanel4.TabIndex = 4;
            // 
            // labelfamily
            // 
            labelfamily.AutoSize = true;
            labelfamily.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelfamily.Location = new Point(3, 0);
            labelfamily.Name = "labelfamily";
            labelfamily.Size = new Size(188, 37);
            labelfamily.TabIndex = 0;
            labelfamily.Text = "Price : ₱4700";
            // 
            // lblFamily
            // 
            lblFamily.AutoSize = true;
            lblFamily.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFamily.Location = new Point(3, 37);
            lblFamily.Name = "lblFamily";
            lblFamily.Size = new Size(91, 32);
            lblFamily.TabIndex = 2;
            lblFamily.Text = "label11";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(3, 69);
            label12.Name = "label12";
            label12.Size = new Size(407, 224);
            label12.TabIndex = 1;
            label12.Text = resources.GetString("label12.Text");
            // 
            // pictureBox5
            // 
            pictureBox5.Dock = DockStyle.Fill;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(0, 0);
            pictureBox5.Margin = new Padding(3, 4, 3, 4);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(1017, 755);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 5;
            pictureBox5.TabStop = false;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Tick += timer2_Tick;
            // 
            // timer3
            // 
            timer3.Tick += timer3_Tick;
            // 
            // timer4
            // 
            timer4.Tick += timer4_Tick;
            // 
            // ViewRoom
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(flowLayoutPanel1);
            Controls.Add(panel2);
            Controls.Add(flowLayoutPanel3);
            Controls.Add(panel4);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(panel1);
            Controls.Add(flowLayoutPanel4);
            Controls.Add(panel3);
            Controls.Add(pictureBox5);
            Margin = new Padding(3, 4, 3, 4);
            Name = "ViewRoom";
            Size = new Size(1017, 755);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            flowLayoutPanel2.ResumeLayout(false);
            flowLayoutPanel2.PerformLayout();
            flowLayoutPanel3.ResumeLayout(false);
            flowLayoutPanel3.PerformLayout();
            flowLayoutPanel4.ResumeLayout(false);
            flowLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button button1;
        private Panel panel2;
        private Button button2;
        private Panel panel3;
        private Button button3;
        private Panel panel4;
        private Button button4;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label labelstandard;
        private Label label2;
        private Label lblStandard;
        private FlowLayoutPanel flowLayoutPanel2;
        private Label labeldeluxe;
        private Label lblDeluxe;
        private Label label6;
        private FlowLayoutPanel flowLayoutPanel3;
        private Label labelbarkada;
        private Label lblBarkada;
        private Label label9;
        private FlowLayoutPanel flowLayoutPanel4;
        private Label labelfamily;
        private Label lblFamily;
        private Label label12;
        private PictureBox pictureBox5;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
    }
}
