﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static iTextSharp.text.pdf.XfaForm;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace FINAL_PROJECT.User_Control
{
    public partial class ViewRoom : UserControl
    {
 
        public ViewRoom()
        {
            InitializeComponent();
            LoadRemainingRoomsToLabels();
            LoadRoomPrices();
        }
        private bool expand1 = false, expand2 = false, expand3 = false, expand4 = false;

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer2.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer3.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer4.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!expand1)
            {
                flowLayoutPanel1.Width += 100;  // Animate the width
                if (flowLayoutPanel1.Width >= 443)  // Target width 443
                {
                    timer1.Stop();
                    expand1 = true;
                }
            }
            else
            {
                flowLayoutPanel1.Width -= 100;  // Animate the width
                if (flowLayoutPanel1.Width <= 0)  // Target width 0
                {
                    timer1.Stop();
                    expand1 = false;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (!expand2)
            {
                flowLayoutPanel2.Width += 100;  // Animate the width
                if (flowLayoutPanel2.Width >= 443)  // Target width 443
                {
                    timer2.Stop();
                    expand2 = true;
                }
            }
            else
            {
                flowLayoutPanel2.Width -= 100;  // Animate the width
                if (flowLayoutPanel2.Width <= 0)  // Target width 0
                {
                    timer2.Stop();
                    expand2 = false;
                }
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (!expand3)
            {
                flowLayoutPanel3.Width += 100;  // Animate the width
                if (flowLayoutPanel3.Width >= 443)  // Target width 443
                {
                    timer3.Stop();
                    expand3 = true;
                }
            }
            else
            {
                flowLayoutPanel3.Width -= 100;  // Animate the width
                if (flowLayoutPanel3.Width <= 0)  // Target width 0
                {
                    timer3.Stop();
                    expand3 = false;
                }
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            if (!expand4)
            {
                flowLayoutPanel4.Width += 100;  // Animate the width
                if (flowLayoutPanel4.Width >= 443)  // Target width 443
                {
                    timer4.Stop();
                    expand4 = true;
                }
            }
            else
            {
                flowLayoutPanel4.Width -= 100;  // Animate the width
                if (flowLayoutPanel4.Width <= 0)  // Target width 0
                {
                    timer4.Stop();
                    expand4 = false;
                }
            }
        }


        private void LoadRemainingRoomsToLabels()
        {
            try
            {
                using (OleDbConnection myConn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb"))
                {
                    string query = "SELECT RoomTypes, RemainingRooms FROM RoomStatus";

                    using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                    {
                        myConn.Open();
                        using (OleDbDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string roomType = reader["RoomTypes"].ToString();
                                int remaining = Convert.ToInt32(reader["RemainingRooms"]);
                                string labelText = (remaining == 0) ? "Fully Booked" : $"Remaining: {remaining}";
                                Color textColor = (remaining == 0) ? Color.Red : Color.Black;

                                switch (roomType)
                                {
                                    case "Standard Room":
                                        lblStandard.Text = labelText;
                                        lblStandard.ForeColor = textColor;
                                        break;
                                    case "Deluxe Room":
                                        lblDeluxe.Text = labelText;
                                        lblDeluxe.ForeColor = textColor;
                                        break;
                                    case "Barkada Room":
                                        lblBarkada.Text = labelText;
                                        lblBarkada.ForeColor = textColor;
                                        break;
                                    case "Family Room":
                                        lblFamily.Text = labelText;
                                        lblFamily.ForeColor = textColor;
                                        break;
                                }
                            }
                        }
                        myConn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading room counts: " + ex.Message);
            }
        }

        private void LoadRoomPrices()
        {
            try
            {
                using (OleDbConnection myConn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb"))
                {
                    string query = "SELECT RoomTypes, Price FROM RoomStatus";

                    using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                    {
                        myConn.Open();
                        using (OleDbDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string roomType = reader["RoomTypes"].ToString();
                                decimal price = Convert.ToDecimal(reader["Price"]);
                                string priceText = $"₱{price:N2}";

                                // Assign price to corresponding label based on room type
                                switch (roomType)
                                {
                                    case "Standard Room":
                                        labelstandard.Text = priceText;
                                        break;
                                    case "Deluxe Room":
                                        labeldeluxe.Text = priceText;
                                        break;
                                    case "Barkada Room":
                                        labelbarkada.Text = priceText;
                                        break;
                                    case "Family Room":
                                        labelfamily.Text = priceText;
                                        break;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading room prices: " + ex.Message);
            }
        }


    }


}

