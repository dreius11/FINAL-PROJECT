﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace FINAL_PROJECT.User_Control
{
    public partial class accountuser : UserControl
    {
        private OleDbConnection myConn;
        private OleDbDataAdapter da;
        private DataSet ds;

        public accountuser()
        {
            InitializeComponent();
            LoadData();
        }


        public void LoadData()
        {
            try
            {
                myConn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb");

                // Modify query to select data from Employee table
                string query = "SELECT * FROM EmployeeLogin";

                da = new OleDbDataAdapter(query, myConn);

                ds = new DataSet();
                myConn.Open();
                da.Fill(ds, "EmployeeLogin");

                // Bind the DataGridViews to the Employee table
                dataGridView1.DataSource = ds.Tables["EmployeeLogin"];
                dataGridView2.DataSource = ds.Tables["EmployeeLogin"];
                dataGridView3.DataSource = ds.Tables["EmployeeLogin"];

                myConn.Close();

                // Style the DataGridViews
                StyleDataGridView(dataGridView1);
                StyleDataGridView(dataGridView2);
                StyleDataGridView(dataGridView3);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void StyleDataGridView(DataGridView dgv)
        {
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Teal;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.EnableHeadersVisualStyles = false;
            dgv.RowTemplate.Height = 30;
            dgv.RowHeadersVisible = true;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.LightGray;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            dgv.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate required fields (Username and Password)
                if (string.IsNullOrEmpty(Fname.Text) || string.IsNullOrEmpty(Pname.Text))
                {
                    MessageBox.Show("Please fill in all fields (Username and Password).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Get values from input fields
                string username = Fname.Text.Trim();
                string password = Pname.Text.Trim();

                // Database connection string
                string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb";

                using (OleDbConnection myConn = new OleDbConnection(connString))
                {
                    string query = "INSERT INTO EmployeeLogin ([Username], [Password]) VALUES (?, ?)";

                    using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                    {
                        cmd.Parameters.AddWithValue("?", username);
                        cmd.Parameters.AddWithValue("?", password);

                        myConn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        myConn.Close();

                        // Show success or failure message
                        if (rowsAffected > 0)
                        {
                            LoadData(); // Optional: refresh data display if applicable

                            MessageBox.Show("Account added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No data was inserted. Check your database.", "Insert Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView2.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a user to update.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int ID = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["ID"].Value);
                string username = uptFname.Text.Trim();
                string password = uptPname.Text.Trim();

                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Please fill in both Username and Password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DialogResult result = MessageBox.Show($"Are you sure you want to update user '{username}'?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb";
                    string query = "UPDATE EmployeeLogin SET [Username] = ?, [Password] = ? WHERE [ID] = ?";

                    using (OleDbConnection myConn = new OleDbConnection(connString))
                    {
                        using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                        {
                            cmd.Parameters.AddWithValue("?", username);
                            cmd.Parameters.AddWithValue("?", password);
                            cmd.Parameters.AddWithValue("?", ID);

                            myConn.Open();
                            int rowsAffected = cmd.ExecuteNonQuery();
                            myConn.Close();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("User updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadData();
                            }
                            else
                            {
                                MessageBox.Show("No record found to update.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView3.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a user to delete.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int ID = Convert.ToInt32(dataGridView3.SelectedRows[0].Cells["ID"].Value);
                string username = dataGridView3.SelectedRows[0].Cells["Username"].Value.ToString();

                DialogResult result = MessageBox.Show($"Are you sure you want to delete user '{username}'?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb";
                    string query = "DELETE FROM EmployeeLogin WHERE [ID] = ?";

                    using (OleDbConnection myConn = new OleDbConnection(connString))
                    {
                        using (OleDbCommand cmd = new OleDbCommand(query, myConn))
                        {
                            cmd.Parameters.AddWithValue("?", ID);

                            myConn.Open();
                            int rowsAffected = cmd.ExecuteNonQuery();
                            myConn.Close();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("User deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadData();
                            }
                            else
                            {
                                MessageBox.Show("No record found to delete.", "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
