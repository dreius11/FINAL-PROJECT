﻿namespace FINAL_PROJECT.User_Control
{
    partial class clientsuggest
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSuggestion = new TextBox();
            label1 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // txtSuggestion
            // 
            txtSuggestion.Location = new Point(108, 67);
            txtSuggestion.Margin = new Padding(4);
            txtSuggestion.Multiline = true;
            txtSuggestion.Name = "txtSuggestion";
            txtSuggestion.Size = new Size(706, 445);
            txtSuggestion.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Teal;
            label1.Location = new Point(108, 38);
            label1.Name = "label1";
            label1.Size = new Size(153, 25);
            label1.TabIndex = 1;
            label1.Text = "Suggestion Box";
            // 
            // button1
            // 
            button1.BackColor = Color.Teal;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.White;
            button1.Location = new Point(673, 519);
            button1.Name = "button1";
            button1.Size = new Size(141, 35);
            button1.TabIndex = 2;
            button1.Text = "Sumbit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // clientsuggest
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(txtSuggestion);
            Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "clientsuggest";
            Size = new Size(906, 605);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtSuggestion;
        private Label label1;
        private Button button1;
    }
}
