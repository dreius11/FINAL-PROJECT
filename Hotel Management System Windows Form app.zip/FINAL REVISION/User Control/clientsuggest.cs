﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT.User_Control
{
    public partial class clientsuggest : UserControl
    {
        public clientsuggest()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string suggestion = txtSuggestion.Text; // txtSuggestion is your TextBox

            if (string.IsNullOrWhiteSpace(suggestion))
            {
                MessageBox.Show("Please enter a suggestion before submitting.");
                return;
            }

            using (OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;"))
            {
                con.Open();

                // Insert the suggestion into the database
                string insertQuery = "INSERT INTO Suggestion (Suggestion) VALUES (?)";
                using (OleDbCommand cmd = new OleDbCommand(insertQuery, con))
                {
                    cmd.Parameters.AddWithValue("?", suggestion);
                    cmd.ExecuteNonQuery();
                }

                con.Close();
            }

            MessageBox.Show("Thank you for your suggestion!");
            txtSuggestion.Clear(); // Clear the TextBox after submission
        }
    }
}
