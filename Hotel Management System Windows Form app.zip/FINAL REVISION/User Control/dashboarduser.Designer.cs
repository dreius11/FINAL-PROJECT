﻿namespace FINAL_PROJECT
{
    partial class dashboarduser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboarduser));
            panel1 = new Panel();
            lblUserCount = new Label();
            Users = new Label();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            lblGuestCount = new Label();
            Guestnumber = new Label();
            pictureBox2 = new PictureBox();
            panel3 = new Panel();
            lblroomCount = new Label();
            numberofrooms = new Label();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(70, 90, 101);
            panel1.Controls.Add(lblUserCount);
            panel1.Controls.Add(Users);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(112, 158);
            panel1.Name = "panel1";
            panel1.Size = new Size(200, 100);
            panel1.TabIndex = 0;
            // 
            // lblUserCount
            // 
            lblUserCount.AutoSize = true;
            lblUserCount.BackColor = Color.Transparent;
            lblUserCount.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUserCount.ForeColor = Color.White;
            lblUserCount.Location = new Point(114, 38);
            lblUserCount.Name = "lblUserCount";
            lblUserCount.Size = new Size(21, 25);
            lblUserCount.TabIndex = 4;
            lblUserCount.Text = "?";
            // 
            // Users
            // 
            Users.AutoSize = true;
            Users.BackColor = Color.Transparent;
            Users.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Users.ForeColor = Color.White;
            Users.Location = new Point(46, 38);
            Users.Name = "Users";
            Users.Size = new Size(64, 25);
            Users.TabIndex = 3;
            Users.Text = "Guest:";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(51, 42);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(181, 236, 255);
            panel2.Controls.Add(lblGuestCount);
            panel2.Controls.Add(Guestnumber);
            panel2.Controls.Add(pictureBox2);
            panel2.Location = new Point(540, 158);
            panel2.Name = "panel2";
            panel2.Size = new Size(206, 100);
            panel2.TabIndex = 1;
            // 
            // lblGuestCount
            // 
            lblGuestCount.AutoSize = true;
            lblGuestCount.BackColor = Color.Transparent;
            lblGuestCount.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblGuestCount.ForeColor = Color.White;
            lblGuestCount.Location = new Point(152, 38);
            lblGuestCount.Name = "lblGuestCount";
            lblGuestCount.Size = new Size(21, 25);
            lblGuestCount.TabIndex = 5;
            lblGuestCount.Text = "?";
            // 
            // Guestnumber
            // 
            Guestnumber.AutoSize = true;
            Guestnumber.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Guestnumber.ForeColor = Color.White;
            Guestnumber.Location = new Point(32, 38);
            Guestnumber.Name = "Guestnumber";
            Guestnumber.Size = new Size(114, 25);
            Guestnumber.TabIndex = 2;
            Guestnumber.Text = "Reservation:";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(61, 50);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(207, 147, 217);
            panel3.Controls.Add(lblroomCount);
            panel3.Controls.Add(numberofrooms);
            panel3.Controls.Add(pictureBox3);
            panel3.Location = new Point(336, 350);
            panel3.Name = "panel3";
            panel3.Size = new Size(200, 100);
            panel3.TabIndex = 1;
            // 
            // lblroomCount
            // 
            lblroomCount.AutoSize = true;
            lblroomCount.BackColor = Color.Transparent;
            lblroomCount.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblroomCount.ForeColor = Color.White;
            lblroomCount.Location = new Point(142, 44);
            lblroomCount.Name = "lblroomCount";
            lblroomCount.Size = new Size(21, 25);
            lblroomCount.TabIndex = 5;
            lblroomCount.Text = "?";
            // 
            // numberofrooms
            // 
            numberofrooms.AutoSize = true;
            numberofrooms.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            numberofrooms.ForeColor = Color.White;
            numberofrooms.Location = new Point(20, 44);
            numberofrooms.Name = "numberofrooms";
            numberofrooms.Size = new Size(116, 25);
            numberofrooms.TabIndex = 3;
            numberofrooms.Text = "Room Types:";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(0, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(58, 50);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Dock = DockStyle.Fill;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(0, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(906, 605);
            pictureBox4.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox4.TabIndex = 2;
            pictureBox4.TabStop = false;
            // 
            // dashboarduser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(pictureBox4);
            Name = "dashboarduser";
            Size = new Size(906, 605);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private Panel panel2;
        private PictureBox pictureBox2;
        private Panel panel3;
        private PictureBox pictureBox3;
        private Label Users;
        private Label Guestnumber;
        private Label numberofrooms;
        private Label lblUserCount;
        private Label lblGuestCount;
        private Label lblroomCount;
        private PictureBox pictureBox4;
    }
}
