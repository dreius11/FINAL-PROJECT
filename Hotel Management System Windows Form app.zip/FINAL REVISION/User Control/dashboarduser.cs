﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT
{
    public partial class dashboarduser : UserControl
    {
        public dashboarduser()
        {
            InitializeComponent();
            LoadDashboard();
        }
        public void LoadDashboard()
        {
            try
            {
                string connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb";

                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();

                    // Count of checked-in users (guests)
                    OleDbCommand cmdCheckedIn = new OleDbCommand("SELECT COUNT(*) FROM Reservation", conn);
                    int checkedInCount = (int)cmdCheckedIn.ExecuteScalar();

                    // Count of admin users
                    OleDbCommand cmdAdmin = new OleDbCommand("SELECT COUNT(*) FROM AdminLogin", conn);
                    int adminCount = (int)cmdAdmin.ExecuteScalar();

                    // Count of rooms (RoomStatus table holds remaining rooms info)
                    OleDbCommand cmdRooms = new OleDbCommand("SELECT COUNT(*) FROM RoomStatus", conn);
                    int roomCount = (int)cmdRooms.ExecuteScalar();

                    int totalUsers = checkedInCount + adminCount;

                    conn.Close();

                    // Display counts on labels
                    lblUserCount.Text = totalUsers.ToString();
                    lblGuestCount.Text = checkedInCount.ToString();
                    lblroomCount.Text = roomCount.ToString();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving counts: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
