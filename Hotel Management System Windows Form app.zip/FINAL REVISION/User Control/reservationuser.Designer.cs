﻿namespace FINAL_PROJECT.User_Control
{
    partial class reservationuser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControlUser = new TabControl();
            addreserve = new TabPage();
            groupBox1 = new GroupBox();
            CheckCostButton = new Button();
            totalCostLabel = new Label();
            downpaymentLabel = new Label();
            qrPictureBox = new PictureBox();
            gender = new ComboBox();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label10 = new Label();
            nationality = new TextBox();
            address = new TextBox();
            emailAddress = new TextBox();
            checkin = new DateTimePicker();
            checkout = new DateTimePicker();
            label13 = new Label();
            payment = new ComboBox();
            label2 = new Label();
            label5 = new Label();
            Roomtype = new ComboBox();
            label8 = new Label();
            Add = new Button();
            mobileno = new TextBox();
            label9 = new Label();
            label12 = new Label();
            Fname = new TextBox();
            updatereserve = new TabPage();
            updatereserveview = new DataGridView();
            groupBox3 = new GroupBox();
            Checkcost2 = new Button();
            label245 = new Label();
            totalCostLabel2 = new Label();
            qrPictureBox2 = new PictureBox();
            uptgender = new ComboBox();
            label30 = new Label();
            label7 = new Label();
            label28 = new Label();
            label27 = new Label();
            uptnationality = new TextBox();
            uptaddress = new TextBox();
            uptIdproof = new TextBox();
            uptcheckin = new DateTimePicker();
            uptcheckout = new DateTimePicker();
            label26 = new Label();
            uptpayment = new ComboBox();
            label25 = new Label();
            label4 = new Label();
            label3 = new Label();
            uptroomtype = new ComboBox();
            Update = new Button();
            label1 = new Label();
            uptmobileno = new TextBox();
            label24 = new Label();
            uptname = new TextBox();
            searchtxt = new TextBox();
            Searchupdate = new Button();
            deletereserve = new TabPage();
            deletereserveview = new DataGridView();
            groupBox2 = new GroupBox();
            button1 = new Button();
            Delete = new Button();
            label11 = new Label();
            txtSearchDelete = new TextBox();
            view = new TabPage();
            addreserveview = new DataGridView();
            tabControlUser.SuspendLayout();
            addreserve.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)qrPictureBox).BeginInit();
            updatereserve.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)updatereserveview).BeginInit();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)qrPictureBox2).BeginInit();
            deletereserve.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)deletereserveview).BeginInit();
            groupBox2.SuspendLayout();
            view.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)addreserveview).BeginInit();
            SuspendLayout();
            // 
            // tabControlUser
            // 
            tabControlUser.Alignment = TabAlignment.Bottom;
            tabControlUser.Controls.Add(addreserve);
            tabControlUser.Controls.Add(updatereserve);
            tabControlUser.Controls.Add(deletereserve);
            tabControlUser.Controls.Add(view);
            tabControlUser.Dock = DockStyle.Fill;
            tabControlUser.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabControlUser.Location = new Point(0, 0);
            tabControlUser.Multiline = true;
            tabControlUser.Name = "tabControlUser";
            tabControlUser.SelectedIndex = 0;
            tabControlUser.Size = new Size(906, 605);
            tabControlUser.TabIndex = 1;
            // 
            // addreserve
            // 
            addreserve.Controls.Add(groupBox1);
            addreserve.Location = new Point(4, 4);
            addreserve.Name = "addreserve";
            addreserve.Padding = new Padding(3, 3, 3, 3);
            addreserve.Size = new Size(898, 571);
            addreserve.TabIndex = 0;
            addreserve.Text = "Add Reservation";
            addreserve.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Teal;
            groupBox1.Controls.Add(CheckCostButton);
            groupBox1.Controls.Add(totalCostLabel);
            groupBox1.Controls.Add(downpaymentLabel);
            groupBox1.Controls.Add(qrPictureBox);
            groupBox1.Controls.Add(gender);
            groupBox1.Controls.Add(label17);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(nationality);
            groupBox1.Controls.Add(address);
            groupBox1.Controls.Add(emailAddress);
            groupBox1.Controls.Add(checkin);
            groupBox1.Controls.Add(checkout);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(payment);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(Roomtype);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(Add);
            groupBox1.Controls.Add(mobileno);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(Fname);
            groupBox1.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.White;
            groupBox1.ImeMode = ImeMode.NoControl;
            groupBox1.Location = new Point(33, 40);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(833, 501);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Add Reservation";
            // 
            // CheckCostButton
            // 
            CheckCostButton.Anchor = AnchorStyles.None;
            CheckCostButton.BackColor = Color.White;
            CheckCostButton.BackgroundImageLayout = ImageLayout.None;
            CheckCostButton.Cursor = Cursors.Hand;
            CheckCostButton.FlatAppearance.BorderSize = 0;
            CheckCostButton.FlatStyle = FlatStyle.Flat;
            CheckCostButton.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CheckCostButton.ForeColor = Color.Teal;
            CheckCostButton.ImageAlign = ContentAlignment.MiddleLeft;
            CheckCostButton.Location = new Point(344, 453);
            CheckCostButton.Margin = new Padding(4, 4, 4, 4);
            CheckCostButton.Name = "CheckCostButton";
            CheckCostButton.RightToLeft = RightToLeft.No;
            CheckCostButton.Size = new Size(158, 32);
            CheckCostButton.TabIndex = 73;
            CheckCostButton.Text = "Check Cost";
            CheckCostButton.TextImageRelation = TextImageRelation.TextBeforeImage;
            CheckCostButton.UseVisualStyleBackColor = false;
            CheckCostButton.Click += CheckCostButton_Click;
            // 
            // totalCostLabel
            // 
            totalCostLabel.AutoSize = true;
            totalCostLabel.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            totalCostLabel.Location = new Point(344, 394);
            totalCostLabel.Name = "totalCostLabel";
            totalCostLabel.Size = new Size(20, 25);
            totalCostLabel.TabIndex = 72;
            totalCostLabel.Text = "?";
            // 
            // downpaymentLabel
            // 
            downpaymentLabel.AutoSize = true;
            downpaymentLabel.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            downpaymentLabel.Location = new Point(344, 366);
            downpaymentLabel.Name = "downpaymentLabel";
            downpaymentLabel.Size = new Size(20, 25);
            downpaymentLabel.TabIndex = 70;
            downpaymentLabel.Text = "?";
            // 
            // qrPictureBox
            // 
            qrPictureBox.Location = new Point(648, 331);
            qrPictureBox.Name = "qrPictureBox";
            qrPictureBox.Size = new Size(150, 150);
            qrPictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            qrPictureBox.TabIndex = 69;
            qrPictureBox.TabStop = false;
            // 
            // gender
            // 
            gender.Font = new Font("Nirmala UI", 12F);
            gender.FormattingEnabled = true;
            gender.Items.AddRange(new object[] { "Male", "Female", "Prefer not to say" });
            gender.Location = new Point(324, 273);
            gender.Name = "gender";
            gender.Size = new Size(204, 29);
            gender.TabIndex = 68;
            // 
            // label17
            // 
            label17.Anchor = AnchorStyles.None;
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.White;
            label17.Location = new Point(594, 64);
            label17.Margin = new Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new Size(53, 21);
            label17.TabIndex = 67;
            label17.Text = "Email";
            // 
            // label16
            // 
            label16.Anchor = AnchorStyles.None;
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.White;
            label16.Location = new Point(54, 157);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(70, 21);
            label16.TabIndex = 66;
            label16.Text = "Address";
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.None;
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.White;
            label15.Location = new Point(324, 248);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(65, 21);
            label15.TabIndex = 65;
            label15.Text = "Gender";
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(54, 249);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(97, 21);
            label10.TabIndex = 64;
            label10.Text = "Nationality";
            // 
            // nationality
            // 
            nationality.Font = new Font("Nirmala UI", 12F);
            nationality.Location = new Point(54, 273);
            nationality.Name = "nationality";
            nationality.Size = new Size(204, 29);
            nationality.TabIndex = 63;
            // 
            // address
            // 
            address.Font = new Font("Nirmala UI", 12F);
            address.Location = new Point(54, 181);
            address.Name = "address";
            address.Size = new Size(204, 29);
            address.TabIndex = 62;
            // 
            // emailAddress
            // 
            emailAddress.Font = new Font("Nirmala UI", 12F);
            emailAddress.Location = new Point(594, 88);
            emailAddress.Name = "emailAddress";
            emailAddress.Size = new Size(204, 29);
            emailAddress.TabIndex = 61;
            // 
            // checkin
            // 
            checkin.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkin.Format = DateTimePickerFormat.Short;
            checkin.Location = new Point(324, 181);
            checkin.Name = "checkin";
            checkin.Size = new Size(204, 29);
            checkin.TabIndex = 59;
            // 
            // checkout
            // 
            checkout.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkout.Format = DateTimePickerFormat.Short;
            checkout.Location = new Point(594, 179);
            checkout.Name = "checkout";
            checkout.Size = new Size(204, 29);
            checkout.TabIndex = 58;
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.None;
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.White;
            label13.Location = new Point(54, 331);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(77, 21);
            label13.TabIndex = 57;
            label13.Text = "Payment";
            // 
            // payment
            // 
            payment.Font = new Font("Nirmala UI", 12F);
            payment.FormattingEnabled = true;
            payment.Items.AddRange(new object[] { "Cash", "GCash", "Paymaya", "Banktransfer" });
            payment.Location = new Point(54, 362);
            payment.Name = "payment";
            payment.Size = new Size(204, 29);
            payment.TabIndex = 56;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(594, 157);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(89, 21);
            label2.TabIndex = 55;
            label2.Text = "Check-Out";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(324, 157);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(76, 21);
            label5.TabIndex = 53;
            label5.Text = "Check-In";
            // 
            // Roomtype
            // 
            Roomtype.Font = new Font("Nirmala UI", 12F);
            Roomtype.FormattingEnabled = true;
            Roomtype.Items.AddRange(new object[] { "Standard Room", "Deluxe Room", "Barkada Room", "Family Room" });
            Roomtype.Location = new Point(594, 273);
            Roomtype.Name = "Roomtype";
            Roomtype.Size = new Size(204, 29);
            Roomtype.TabIndex = 51;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(594, 249);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(95, 21);
            label8.TabIndex = 50;
            label8.Text = "Room Type";
            // 
            // Add
            // 
            Add.Anchor = AnchorStyles.None;
            Add.BackColor = Color.White;
            Add.BackgroundImageLayout = ImageLayout.None;
            Add.Cursor = Cursors.Hand;
            Add.FlatAppearance.BorderSize = 0;
            Add.FlatStyle = FlatStyle.Flat;
            Add.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Add.ForeColor = Color.Teal;
            Add.ImageAlign = ContentAlignment.MiddleLeft;
            Add.Location = new Point(81, 453);
            Add.Margin = new Padding(4, 4, 4, 4);
            Add.Name = "Add";
            Add.RightToLeft = RightToLeft.No;
            Add.Size = new Size(158, 32);
            Add.TabIndex = 49;
            Add.Text = "Add";
            Add.TextImageRelation = TextImageRelation.ImageBeforeText;
            Add.UseVisualStyleBackColor = false;
            Add.Click += Add_Click;
            // 
            // mobileno
            // 
            mobileno.Font = new Font("Nirmala UI", 12F);
            mobileno.Location = new Point(324, 88);
            mobileno.Name = "mobileno";
            mobileno.Size = new Size(204, 29);
            mobileno.TabIndex = 2;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(324, 64);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(95, 21);
            label9.TabIndex = 45;
            label9.Text = "Mobile No.";
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.None;
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.White;
            label12.Location = new Point(54, 64);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(56, 21);
            label12.TabIndex = 44;
            label12.Text = "Name";
            // 
            // Fname
            // 
            Fname.Font = new Font("Nirmala UI", 12F);
            Fname.Location = new Point(54, 88);
            Fname.Name = "Fname";
            Fname.Size = new Size(204, 29);
            Fname.TabIndex = 1;
            // 
            // updatereserve
            // 
            updatereserve.Controls.Add(updatereserveview);
            updatereserve.Controls.Add(groupBox3);
            updatereserve.Controls.Add(searchtxt);
            updatereserve.Controls.Add(Searchupdate);
            updatereserve.Location = new Point(4, 4);
            updatereserve.Name = "updatereserve";
            updatereserve.Padding = new Padding(3, 3, 3, 3);
            updatereserve.Size = new Size(898, 571);
            updatereserve.TabIndex = 1;
            updatereserve.Text = "Update Reservation";
            updatereserve.UseVisualStyleBackColor = true;
            // 
            // updatereserveview
            // 
            updatereserveview.AllowUserToAddRows = false;
            updatereserveview.AllowUserToDeleteRows = false;
            updatereserveview.BackgroundColor = Color.White;
            updatereserveview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            updatereserveview.Location = new Point(628, 64);
            updatereserveview.Name = "updatereserveview";
            updatereserveview.ReadOnly = true;
            updatereserveview.RowHeadersWidth = 51;
            updatereserveview.Size = new Size(267, 504);
            updatereserveview.TabIndex = 1;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.White;
            groupBox3.BackgroundImageLayout = ImageLayout.Zoom;
            groupBox3.Controls.Add(Checkcost2);
            groupBox3.Controls.Add(label245);
            groupBox3.Controls.Add(totalCostLabel2);
            groupBox3.Controls.Add(qrPictureBox2);
            groupBox3.Controls.Add(uptgender);
            groupBox3.Controls.Add(label30);
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(label28);
            groupBox3.Controls.Add(label27);
            groupBox3.Controls.Add(uptnationality);
            groupBox3.Controls.Add(uptaddress);
            groupBox3.Controls.Add(uptIdproof);
            groupBox3.Controls.Add(uptcheckin);
            groupBox3.Controls.Add(uptcheckout);
            groupBox3.Controls.Add(label26);
            groupBox3.Controls.Add(uptpayment);
            groupBox3.Controls.Add(label25);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(uptroomtype);
            groupBox3.Controls.Add(Update);
            groupBox3.Controls.Add(label1);
            groupBox3.Controls.Add(uptmobileno);
            groupBox3.Controls.Add(label24);
            groupBox3.Controls.Add(uptname);
            groupBox3.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox3.ForeColor = Color.White;
            groupBox3.ImeMode = ImeMode.NoControl;
            groupBox3.Location = new Point(6, 28);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(615, 537);
            groupBox3.TabIndex = 63;
            groupBox3.TabStop = false;
            groupBox3.Text = "Update Reservation";
            // 
            // Checkcost2
            // 
            Checkcost2.Anchor = AnchorStyles.None;
            Checkcost2.BackColor = Color.Teal;
            Checkcost2.BackgroundImageLayout = ImageLayout.None;
            Checkcost2.Cursor = Cursors.Hand;
            Checkcost2.FlatAppearance.BorderSize = 0;
            Checkcost2.FlatStyle = FlatStyle.Flat;
            Checkcost2.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Checkcost2.ForeColor = Color.White;
            Checkcost2.ImageAlign = ContentAlignment.MiddleLeft;
            Checkcost2.Location = new Point(218, 460);
            Checkcost2.Margin = new Padding(4, 4, 4, 4);
            Checkcost2.Name = "Checkcost2";
            Checkcost2.RightToLeft = RightToLeft.No;
            Checkcost2.Size = new Size(155, 32);
            Checkcost2.TabIndex = 73;
            Checkcost2.Text = "Check Cost";
            Checkcost2.TextImageRelation = TextImageRelation.TextBeforeImage;
            Checkcost2.UseVisualStyleBackColor = false;
            Checkcost2.Click += Checkcost2_Click;
            // 
            // label245
            // 
            label245.AutoSize = true;
            label245.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label245.ForeColor = Color.Teal;
            label245.Location = new Point(218, 404);
            label245.Name = "label245";
            label245.Size = new Size(20, 25);
            label245.TabIndex = 72;
            label245.Text = "?";
            // 
            // totalCostLabel2
            // 
            totalCostLabel2.AutoSize = true;
            totalCostLabel2.Font = new Font("Nirmala UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            totalCostLabel2.ForeColor = Color.Teal;
            totalCostLabel2.Location = new Point(218, 366);
            totalCostLabel2.Name = "totalCostLabel2";
            totalCostLabel2.Size = new Size(20, 25);
            totalCostLabel2.TabIndex = 70;
            totalCostLabel2.Text = "?";
            // 
            // qrPictureBox2
            // 
            qrPictureBox2.Location = new Point(459, 381);
            qrPictureBox2.Name = "qrPictureBox2";
            qrPictureBox2.Size = new Size(150, 150);
            qrPictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            qrPictureBox2.TabIndex = 69;
            qrPictureBox2.TabStop = false;
            qrPictureBox2.Visible = false;
            // 
            // uptgender
            // 
            uptgender.Font = new Font("Nirmala UI", 12F);
            uptgender.FormattingEnabled = true;
            uptgender.Items.AddRange(new object[] { "Male", "Female", "Prefer not to say" });
            uptgender.Location = new Point(218, 181);
            uptgender.Name = "uptgender";
            uptgender.Size = new Size(155, 29);
            uptgender.TabIndex = 68;
            // 
            // label30
            // 
            label30.Anchor = AnchorStyles.None;
            label30.AutoSize = true;
            label30.BackColor = Color.Transparent;
            label30.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label30.ForeColor = Color.Teal;
            label30.Location = new Point(218, 249);
            label30.Margin = new Padding(4, 0, 4, 0);
            label30.Name = "label30";
            label30.Size = new Size(73, 21);
            label30.TabIndex = 67;
            label30.Text = "ID Proof";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Teal;
            label7.Location = new Point(15, 157);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(70, 21);
            label7.TabIndex = 66;
            label7.Text = "Address";
            // 
            // label28
            // 
            label28.Anchor = AnchorStyles.None;
            label28.AutoSize = true;
            label28.BackColor = Color.Transparent;
            label28.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label28.ForeColor = Color.Teal;
            label28.Location = new Point(218, 157);
            label28.Margin = new Padding(4, 0, 4, 0);
            label28.Name = "label28";
            label28.Size = new Size(65, 21);
            label28.TabIndex = 65;
            label28.Text = "Gender";
            // 
            // label27
            // 
            label27.Anchor = AnchorStyles.None;
            label27.AutoSize = true;
            label27.BackColor = Color.Transparent;
            label27.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label27.ForeColor = Color.Teal;
            label27.Location = new Point(15, 249);
            label27.Margin = new Padding(4, 0, 4, 0);
            label27.Name = "label27";
            label27.Size = new Size(97, 21);
            label27.TabIndex = 64;
            label27.Text = "Nationality";
            // 
            // uptnationality
            // 
            uptnationality.Font = new Font("Nirmala UI", 12F);
            uptnationality.Location = new Point(18, 273);
            uptnationality.Name = "uptnationality";
            uptnationality.Size = new Size(155, 29);
            uptnationality.TabIndex = 63;
            // 
            // uptaddress
            // 
            uptaddress.Font = new Font("Nirmala UI", 12F);
            uptaddress.Location = new Point(18, 181);
            uptaddress.Name = "uptaddress";
            uptaddress.Size = new Size(155, 29);
            uptaddress.TabIndex = 62;
            // 
            // uptIdproof
            // 
            uptIdproof.Font = new Font("Nirmala UI", 12F);
            uptIdproof.Location = new Point(218, 273);
            uptIdproof.Name = "uptIdproof";
            uptIdproof.Size = new Size(155, 29);
            uptIdproof.TabIndex = 61;
            // 
            // uptcheckin
            // 
            uptcheckin.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            uptcheckin.Format = DateTimePickerFormat.Short;
            uptcheckin.Location = new Point(424, 88);
            uptcheckin.Name = "uptcheckin";
            uptcheckin.Size = new Size(155, 29);
            uptcheckin.TabIndex = 59;
            // 
            // uptcheckout
            // 
            uptcheckout.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            uptcheckout.Format = DateTimePickerFormat.Short;
            uptcheckout.Location = new Point(424, 178);
            uptcheckout.Name = "uptcheckout";
            uptcheckout.Size = new Size(155, 29);
            uptcheckout.TabIndex = 58;
            // 
            // label26
            // 
            label26.Anchor = AnchorStyles.None;
            label26.AutoSize = true;
            label26.BackColor = Color.Transparent;
            label26.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label26.ForeColor = Color.Teal;
            label26.Location = new Point(18, 338);
            label26.Margin = new Padding(4, 0, 4, 0);
            label26.Name = "label26";
            label26.Size = new Size(77, 21);
            label26.TabIndex = 57;
            label26.Text = "Payment";
            // 
            // uptpayment
            // 
            uptpayment.Font = new Font("Nirmala UI", 12F);
            uptpayment.FormattingEnabled = true;
            uptpayment.Items.AddRange(new object[] { "Cash", "GCash", "Paymaya", "Banktransfer" });
            uptpayment.Location = new Point(18, 362);
            uptpayment.Name = "uptpayment";
            uptpayment.Size = new Size(155, 29);
            uptpayment.TabIndex = 56;
            // 
            // label25
            // 
            label25.Anchor = AnchorStyles.None;
            label25.AutoSize = true;
            label25.BackColor = Color.Transparent;
            label25.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label25.ForeColor = Color.Teal;
            label25.Location = new Point(424, 157);
            label25.Margin = new Padding(4, 0, 4, 0);
            label25.Name = "label25";
            label25.Size = new Size(89, 21);
            label25.TabIndex = 55;
            label25.Text = "Check-Out";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Teal;
            label4.Location = new Point(424, 64);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(76, 21);
            label4.TabIndex = 53;
            label4.Text = "Check-In";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Teal;
            label3.Location = new Point(424, 249);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(95, 21);
            label3.TabIndex = 50;
            label3.Text = "Room Type";
            // 
            // uptroomtype
            // 
            uptroomtype.Font = new Font("Nirmala UI", 12F);
            uptroomtype.FormattingEnabled = true;
            uptroomtype.Items.AddRange(new object[] { "Standard Room", "Deluxe Room", "Family Room" });
            uptroomtype.Location = new Point(424, 273);
            uptroomtype.Name = "uptroomtype";
            uptroomtype.Size = new Size(155, 29);
            uptroomtype.TabIndex = 51;
            // 
            // Update
            // 
            Update.Anchor = AnchorStyles.None;
            Update.BackColor = Color.Teal;
            Update.BackgroundImageLayout = ImageLayout.None;
            Update.Cursor = Cursors.Hand;
            Update.FlatAppearance.BorderSize = 0;
            Update.FlatStyle = FlatStyle.Flat;
            Update.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Update.ForeColor = Color.White;
            Update.ImageAlign = ContentAlignment.MiddleLeft;
            Update.Location = new Point(18, 460);
            Update.Margin = new Padding(4, 4, 4, 4);
            Update.Name = "Update";
            Update.RightToLeft = RightToLeft.No;
            Update.Size = new Size(155, 32);
            Update.TabIndex = 49;
            Update.Text = "Update";
            Update.TextImageRelation = TextImageRelation.ImageBeforeText;
            Update.UseVisualStyleBackColor = false;
            Update.Click += Update_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Teal;
            label1.Location = new Point(218, 64);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(95, 21);
            label1.TabIndex = 45;
            label1.Text = "Mobile No.";
            // 
            // uptmobileno
            // 
            uptmobileno.Font = new Font("Nirmala UI", 12F);
            uptmobileno.Location = new Point(218, 88);
            uptmobileno.Name = "uptmobileno";
            uptmobileno.Size = new Size(155, 29);
            uptmobileno.TabIndex = 2;
            // 
            // label24
            // 
            label24.Anchor = AnchorStyles.None;
            label24.AutoSize = true;
            label24.BackColor = Color.Transparent;
            label24.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label24.ForeColor = Color.Teal;
            label24.Location = new Point(18, 64);
            label24.Margin = new Padding(4, 0, 4, 0);
            label24.Name = "label24";
            label24.Size = new Size(56, 21);
            label24.TabIndex = 44;
            label24.Text = "Name";
            // 
            // uptname
            // 
            uptname.Font = new Font("Nirmala UI", 12F);
            uptname.Location = new Point(18, 88);
            uptname.Name = "uptname";
            uptname.Size = new Size(155, 29);
            uptname.TabIndex = 1;
            // 
            // searchtxt
            // 
            searchtxt.Font = new Font("Nirmala UI", 12F);
            searchtxt.Location = new Point(628, 28);
            searchtxt.Name = "searchtxt";
            searchtxt.Size = new Size(183, 29);
            searchtxt.TabIndex = 0;
            // 
            // Searchupdate
            // 
            Searchupdate.Anchor = AnchorStyles.None;
            Searchupdate.BackColor = Color.Teal;
            Searchupdate.BackgroundImageLayout = ImageLayout.None;
            Searchupdate.Cursor = Cursors.Hand;
            Searchupdate.FlatAppearance.BorderSize = 0;
            Searchupdate.FlatStyle = FlatStyle.Flat;
            Searchupdate.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Searchupdate.ForeColor = Color.White;
            Searchupdate.ImageAlign = ContentAlignment.MiddleLeft;
            Searchupdate.Location = new Point(818, 28);
            Searchupdate.Margin = new Padding(4, 4, 4, 4);
            Searchupdate.Name = "Searchupdate";
            Searchupdate.RightToLeft = RightToLeft.No;
            Searchupdate.Size = new Size(73, 29);
            Searchupdate.TabIndex = 62;
            Searchupdate.Text = "Search";
            Searchupdate.TextImageRelation = TextImageRelation.ImageBeforeText;
            Searchupdate.UseVisualStyleBackColor = false;
            Searchupdate.Click += Searchupdate_Click;
            // 
            // deletereserve
            // 
            deletereserve.Controls.Add(deletereserveview);
            deletereserve.Controls.Add(groupBox2);
            deletereserve.Location = new Point(4, 4);
            deletereserve.Name = "deletereserve";
            deletereserve.Padding = new Padding(3, 3, 3, 3);
            deletereserve.Size = new Size(898, 571);
            deletereserve.TabIndex = 2;
            deletereserve.Text = "Delete Reservation";
            deletereserve.UseVisualStyleBackColor = true;
            // 
            // deletereserveview
            // 
            deletereserveview.AllowUserToAddRows = false;
            deletereserveview.AllowUserToDeleteRows = false;
            deletereserveview.BackgroundColor = Color.White;
            deletereserveview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            deletereserveview.Location = new Point(266, 3);
            deletereserveview.Name = "deletereserveview";
            deletereserveview.ReadOnly = true;
            deletereserveview.RowHeadersWidth = 51;
            deletereserveview.Size = new Size(626, 562);
            deletereserveview.TabIndex = 2;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Teal;
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(Delete);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(txtSearchDelete);
            groupBox2.Font = new Font("Nirmala UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.ForeColor = Color.White;
            groupBox2.Location = new Point(28, 28);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(232, 397);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "Delete Reservation";
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.None;
            button1.BackColor = Color.White;
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Teal;
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(57, 238);
            button1.Margin = new Padding(4, 4, 4, 4);
            button1.Name = "button1";
            button1.RightToLeft = RightToLeft.No;
            button1.Size = new Size(100, 28);
            button1.TabIndex = 48;
            button1.Text = "Search";
            button1.TextImageRelation = TextImageRelation.ImageBeforeText;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Delete
            // 
            Delete.Anchor = AnchorStyles.None;
            Delete.BackColor = Color.White;
            Delete.BackgroundImageLayout = ImageLayout.None;
            Delete.Cursor = Cursors.Hand;
            Delete.FlatAppearance.BorderSize = 0;
            Delete.FlatStyle = FlatStyle.Flat;
            Delete.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Delete.ForeColor = Color.Teal;
            Delete.ImageAlign = ContentAlignment.MiddleLeft;
            Delete.Location = new Point(57, 274);
            Delete.Margin = new Padding(4, 4, 4, 4);
            Delete.Name = "Delete";
            Delete.RightToLeft = RightToLeft.No;
            Delete.Size = new Size(100, 28);
            Delete.TabIndex = 47;
            Delete.Text = "Delete";
            Delete.TextImageRelation = TextImageRelation.ImageBeforeText;
            Delete.UseVisualStyleBackColor = false;
            Delete.Click += Delete_Click;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.None;
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.White;
            label11.Location = new Point(10, 153);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(56, 21);
            label11.TabIndex = 44;
            label11.Text = "Name";
            // 
            // txtSearchDelete
            // 
            txtSearchDelete.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSearchDelete.Location = new Point(10, 177);
            txtSearchDelete.Name = "txtSearchDelete";
            txtSearchDelete.Size = new Size(204, 29);
            txtSearchDelete.TabIndex = 1;
            // 
            // view
            // 
            view.Controls.Add(addreserveview);
            view.Location = new Point(4, 4);
            view.Name = "view";
            view.Padding = new Padding(3, 3, 3, 3);
            view.Size = new Size(898, 571);
            view.TabIndex = 3;
            view.Text = "View Reservation";
            view.UseVisualStyleBackColor = true;
            // 
            // addreserveview
            // 
            addreserveview.AllowUserToAddRows = false;
            addreserveview.AllowUserToDeleteRows = false;
            addreserveview.BackgroundColor = Color.White;
            addreserveview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            addreserveview.Dock = DockStyle.Fill;
            addreserveview.Location = new Point(3, 3);
            addreserveview.Name = "addreserveview";
            addreserveview.ReadOnly = true;
            addreserveview.RowHeadersWidth = 51;
            addreserveview.Size = new Size(892, 565);
            addreserveview.TabIndex = 4;
            // 
            // reservationuser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tabControlUser);
            Name = "reservationuser";
            Size = new Size(906, 605);
            tabControlUser.ResumeLayout(false);
            addreserve.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)qrPictureBox).EndInit();
            updatereserve.ResumeLayout(false);
            updatereserve.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)updatereserveview).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)qrPictureBox2).EndInit();
            deletereserve.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)deletereserveview).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            view.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)addreserveview).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControlUser;
        private TabPage addreserve;
        private TabPage updatereserve;
        private DataGridView updatereserveview;
        private TabPage deletereserve;
        private DataGridView deletereserveview;
        private GroupBox groupBox2;
        private Button Delete;
        private Label label11;
        private TextBox txtSearchDelete;
        private GroupBox groupBox1;
        private Label label2;
        private Label label5;
        private ComboBox Roomtype;
        private Label label8;
        private Button Add;
        private TextBox mobileno;
        private Label label9;
        private Label label12;
        private TextBox Fname;
        private Label label13;
        private ComboBox payment;
        private DateTimePicker checkin;
        private DateTimePicker checkout;
        private Button button1;
        private Button Searchupdate;
        private TextBox searchtxt;
        private TabPage view;
        private DataGridView addreserveview;
        private ComboBox gender;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label10;
        private TextBox nationality;
        private TextBox address;
        private TextBox emailAddress;
        private PictureBox qrPictureBox;
        private Label totalCostLabel;
        private Label downpaymentLabel;
        private Button CheckCostButton;
        private GroupBox groupBox3;
        private Button Checkcost2;
        private Label label245;
        private Label totalCostLabel2;
        private PictureBox qrPictureBox2;
        private ComboBox uptgender;
        private Label label7;
        private TextBox uptnationality;
        private TextBox uptaddress;
        private TextBox uptIdproof;
        private DateTimePicker uptcheckin;
        private DateTimePicker uptcheckout;
        private ComboBox uptpayment;
        private ComboBox uptroomtype;
        private Button Update;
        private TextBox uptmobileno;
        private Label label24;
        private TextBox uptname;
        private Label label30;
        private Label label28;
        private Label label27;
        private Label label26;
        private Label label25;
        private Label label4;
        private Label label3;
        private Label label1;
    }
}
