﻿namespace FINAL_PROJECT
{
    partial class revenue
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            chartRoomType = new System.Windows.Forms.DataVisualization.Charting.Chart();
            chartPaymentMethod = new System.Windows.Forms.DataVisualization.Charting.Chart();
            chartMonthlyRevenue = new System.Windows.Forms.DataVisualization.Charting.Chart();
            panel1 = new Panel();
            cmbMonth = new ComboBox();
            lblPercentageInfo = new Label();
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            chartYearlyRevenue = new System.Windows.Forms.DataVisualization.Charting.Chart();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)chartRoomType).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chartPaymentMethod).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chartMonthlyRevenue).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chartYearlyRevenue).BeginInit();
            SuspendLayout();
            // 
            // chartRoomType
            // 
            chartRoomType.BorderlineColor = Color.Black;
            chartRoomType.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea1.Name = "ChartArea1";
            chartRoomType.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            chartRoomType.Legends.Add(legend1);
            chartRoomType.Location = new Point(34, 59);
            chartRoomType.Margin = new Padding(3, 4, 3, 4);
            chartRoomType.Name = "chartRoomType";
            chartRoomType.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            chartRoomType.Series.Add(series1);
            chartRoomType.Size = new Size(457, 267);
            chartRoomType.TabIndex = 0;
            chartRoomType.Text = "chart1";
            // 
            // chartPaymentMethod
            // 
            chartPaymentMethod.BorderlineColor = Color.Black;
            chartPaymentMethod.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea2.Name = "ChartArea1";
            chartPaymentMethod.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            chartPaymentMethod.Legends.Add(legend2);
            chartPaymentMethod.Location = new Point(34, 392);
            chartPaymentMethod.Margin = new Padding(3, 4, 3, 4);
            chartPaymentMethod.Name = "chartPaymentMethod";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            chartPaymentMethod.Series.Add(series2);
            chartPaymentMethod.Size = new Size(457, 299);
            chartPaymentMethod.TabIndex = 1;
            chartPaymentMethod.Text = "chart2";
            // 
            // chartMonthlyRevenue
            // 
            chartMonthlyRevenue.BorderlineColor = Color.Black;
            chartMonthlyRevenue.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea3.Name = "ChartArea1";
            chartMonthlyRevenue.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            chartMonthlyRevenue.Legends.Add(legend3);
            chartMonthlyRevenue.Location = new Point(75, 0);
            chartMonthlyRevenue.Margin = new Padding(3, 4, 3, 4);
            chartMonthlyRevenue.Name = "chartMonthlyRevenue";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            chartMonthlyRevenue.Series.Add(series3);
            chartMonthlyRevenue.Size = new Size(551, 267);
            chartMonthlyRevenue.TabIndex = 2;
            chartMonthlyRevenue.Text = "chart3";
            // 
            // panel1
            // 
            panel1.Controls.Add(chartMonthlyRevenue);
            panel1.Controls.Add(cmbMonth);
            panel1.Location = new Point(585, 26);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(467, 344);
            panel1.TabIndex = 4;
            // 
            // cmbMonth
            // 
            cmbMonth.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmbMonth.FormattingEnabled = true;
            cmbMonth.Items.AddRange(new object[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" });
            cmbMonth.Location = new Point(173, 308);
            cmbMonth.Margin = new Padding(3, 4, 3, 4);
            cmbMonth.Name = "cmbMonth";
            cmbMonth.Size = new Size(185, 36);
            cmbMonth.TabIndex = 3;
            // 
            // lblPercentageInfo
            // 
            lblPercentageInfo.AutoSize = true;
            lblPercentageInfo.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPercentageInfo.Location = new Point(336, 547);
            lblPercentageInfo.Name = "lblPercentageInfo";
            lblPercentageInfo.Size = new Size(20, 28);
            lblPercentageInfo.TabIndex = 5;
            lblPercentageInfo.Text = "/";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(142, 723);
            label1.Name = "label1";
            label1.Size = new Size(198, 32);
            label1.TabIndex = 6;
            label1.Text = "Payment Method";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(142, 329);
            label2.Name = "label2";
            label2.Size = new Size(134, 32);
            label2.TabIndex = 7;
            label2.Text = "Room Type";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Location = new Point(579, 82);
            label4.Name = "label4";
            label4.Size = new Size(0, 20);
            label4.TabIndex = 9;
            // 
            // chartYearlyRevenue
            // 
            chartYearlyRevenue.BorderlineColor = Color.Black;
            chartYearlyRevenue.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea4.Name = "ChartArea1";
            chartYearlyRevenue.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            chartYearlyRevenue.Legends.Add(legend4);
            chartYearlyRevenue.Location = new Point(660, 410);
            chartYearlyRevenue.Margin = new Padding(3, 4, 3, 4);
            chartYearlyRevenue.Name = "chartYearlyRevenue";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            chartYearlyRevenue.Series.Add(series4);
            chartYearlyRevenue.Size = new Size(551, 266);
            chartYearlyRevenue.TabIndex = 2;
            chartYearlyRevenue.Text = "chart3";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Nirmala UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(754, 723);
            label5.Name = "label5";
            label5.Size = new Size(175, 32);
            label5.TabIndex = 10;
            label5.Text = "Yearly Revenue";
            // 
            // revenue
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label5);
            Controls.Add(chartYearlyRevenue);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblPercentageInfo);
            Controls.Add(chartPaymentMethod);
            Controls.Add(chartRoomType);
            Controls.Add(panel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "revenue";
            Size = new Size(1035, 807);
            ((System.ComponentModel.ISupportInitialize)chartRoomType).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartPaymentMethod).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartMonthlyRevenue).EndInit();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)chartYearlyRevenue).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chartRoomType;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPaymentMethod;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMonthlyRevenue;
        private Panel panel1;
        private ComboBox cmbMonth;
        private Label lblPercentageInfo;
        private Label label1;
        private Label label2;
        private Label label4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartYearlyRevenue;
        private Label label5;
    }
}
