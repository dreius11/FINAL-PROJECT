﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace FINAL_PROJECT
{
    public partial class revenue : UserControl
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb");


        public revenue()
        {
            InitializeComponent();
            this.Load += revenu__Load;
        }
        private void PopulateMonthComboBox()
        {
            cmbMonth.Items.Clear();
            for (int i = 1; i <= 12; i++)
            {
                string monthName = new DateTime(2000, i, 1).ToString("MMMM");
                cmbMonth.Items.Add(monthName);
            }

            cmbMonth.SelectedIndex = 0; 
        }

        private void revenu__Load(object sender, EventArgs e)
        {
            if (!DesignMode)
            {
                LoadRoomTypeChart();
                LoadPaymentMethodChart();
                LoadYearlyRevenueChart();

                PopulateMonthComboBox();
                cmbMonth.SelectedIndexChanged += cmbMonth_SelectedIndexChanged;
                LoadMonthlyRevenueChart(cmbMonth.SelectedIndex + 1);
            }
        }
        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedMonth = cmbMonth.SelectedIndex + 1;
            LoadMonthlyRevenueChart(selectedMonth);
        }



        private void btnLoadCharts_Click(object sender, EventArgs e)
        {
            LoadRoomTypeChart();
            LoadPaymentMethodChart();
            PopulateMonthComboBox();
            cmbMonth.SelectedIndexChanged += cmbMonth_SelectedIndexChanged;
            LoadMonthlyRevenueChart(cmbMonth.SelectedIndex + 1);
        }
        private void LoadRoomTypeChart()
        {
            string query = "SELECT RoomType, COUNT(*) AS Total FROM Reservation GROUP BY RoomType";

            con.Open();
            OleDbDataAdapter da = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            chartRoomType.Series.Clear();
            chartRoomType.ChartAreas.Clear();
            chartRoomType.Titles.Clear();
            chartRoomType.Legends.Clear();
            chartRoomType.ChartAreas.Add(new ChartArea("MainArea"));

            // Create one series per room type (for side-by-side comparison)
            int index = 0;
            Color[] colors = { Color.SteelBlue, Color.MediumSeaGreen, Color.OrangeRed, Color.MediumPurple };

            foreach (DataRow row in dt.Rows)
            {
                string roomType = row["RoomType"].ToString();
                int total = Convert.ToInt32(row["Total"]);

                Series series = new Series(roomType);
                series.ChartType = SeriesChartType.Column;
                series.Points.AddXY(roomType, total);
                series.IsValueShownAsLabel = true;
                series.Color = colors[index % colors.Length];
                series["PointWidth"] = "0.5";
                series.Font = new Font("Segoe UI", 9, FontStyle.Bold);
                series.ToolTip = $"{roomType}: {total} reservations";

                chartRoomType.Series.Add(series);
                index++;
            }

            chartRoomType.ChartAreas[0].AxisX.Title = "Room Types";
            chartRoomType.ChartAreas[0].AxisY.Title = "Number of Reservations";

            chartRoomType.Legends.Add(new Legend("Room Types Legend"));
        }

        private void LoadPaymentMethodChart()
        {
            string query = "SELECT PaymentMethod, COUNT(*) AS Total FROM Reservation GROUP BY PaymentMethod";

            // Load data
            con.Open();
            OleDbDataAdapter da = new OleDbDataAdapter(query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            // Clear and setup chart
            chartPaymentMethod.Series.Clear();
            chartPaymentMethod.ChartAreas.Clear();
            chartPaymentMethod.ChartAreas.Add(new ChartArea("MainArea"));

            Series series = new Series("PaymentMethods")
            {
                ChartType = SeriesChartType.Pie,
                IsValueShownAsLabel = true, // Show values as labels outside the pie
                LabelForeColor = Color.Black,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
            };

            double grandTotal = 0;
            foreach (DataRow row in dt.Rows)
            {
                grandTotal += Convert.ToDouble(row["Total"]);
            }

            // Prepare a string to display percentages elsewhere
            StringBuilder percentageInfo = new StringBuilder("");

            foreach (DataRow row in dt.Rows)
            {
                double count = Convert.ToDouble(row["Total"]);
                double percentage = (count / grandTotal) * 100;

                DataPoint point = new DataPoint
                {
                    AxisLabel = row["PaymentMethod"].ToString(),
                    YValues = new double[] { count },
                    // Set the label to show just the payment method count
                    Label = $"{row["PaymentMethod"]}: {count}"
                };

                series.Points.Add(point);

                // Add the percentage info to the StringBuilder
                percentageInfo.AppendLine($"{row["PaymentMethod"]}: {percentage:F2}%");
            }

            // Add the series to the chart
            chartPaymentMethod.Series.Add(series);
            chartPaymentMethod.Titles.Clear();

            // Display the percentage information in a label or message box
            lblPercentageInfo.Text = percentageInfo.ToString();  // Assuming you have a label named lblPercentageInfo
        }



        private void LoadMonthlyRevenueChart(int selectedMonth)
        {
            string query = @"
SELECT Format(CheckIn, 'mmmm') AS MonthName, SUM(TotalCost) AS TotalRevenue
FROM Reservation
WHERE Month(CheckIn) = @Month
GROUP BY Format(CheckIn, 'mmmm')";

            OleDbCommand cmd = new OleDbCommand(query, con);
            cmd.Parameters.AddWithValue("@Month", selectedMonth);

            con.Open();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            chartMonthlyRevenue.Series.Clear();
            chartMonthlyRevenue.ChartAreas.Clear();
            chartMonthlyRevenue.Titles.Clear(); // This removes the title
            chartMonthlyRevenue.Legends.Clear();

            // Set the size of the chart to make it bigger
            chartMonthlyRevenue.Width = 550;  // You can adjust the width
            chartMonthlyRevenue.Height = 300; // You can adjust the height

            ChartArea area = new ChartArea("MainArea");
            area.AxisX.Title = "Month";
            area.AxisY.Title = "Revenue (₱)";
            area.AxisX.LabelStyle.Angle = 0;
            area.AxisX.Interval = 1;
            area.AxisY.LabelStyle.Format = "₱#,##0";

            // Remove vertical grid lines
            area.AxisX.MajorGrid.Enabled = false;

            chartMonthlyRevenue.ChartAreas.Add(area);

            Series series = new Series("Monthly Revenue")
            {
                ChartType = SeriesChartType.Column,
                IsValueShownAsLabel = true, // Ensure values are shown as labels
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                LabelForeColor = Color.Black,
                ["PointWidth"] = "0.4"
            };

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    string monthName = row["MonthName"].ToString();
                    double revenue = Convert.ToDouble(row["TotalRevenue"]);

                    DataPoint point = new DataPoint
                    {
                        AxisLabel = monthName,
                        YValues = new double[] { revenue },
                        Color = Color.SteelBlue,
                        ToolTip = $"Month: {monthName}\nRevenue: ₱{revenue:N2}",
                        Label = $"{revenue:N2}" // Display the number below the bar
                    };

                    series.Points.Add(point);
                }
            }
            else
            {
                DataPoint point = new DataPoint
                {
                    AxisLabel = new DateTime(2000, selectedMonth, 1).ToString("MMMM"),
                    YValues = new double[] { 0 },
                    Color = Color.LightGray,
                    Label = "₱0.00",
                    ToolTip = "No revenue"
                };

                series.Points.Add(point);
            }

            chartMonthlyRevenue.Series.Add(series);
            chartMonthlyRevenue.Legends.Add(new Legend("Legend"));
        }





        private void LoadChart(Chart chart, string query, string xMember, string yMember, SeriesChartType chartType, string title)
        {
            try
            {
                con.Open();
                OleDbDataAdapter da = new OleDbDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                con.Close();

                chart.Series.Clear();
                chart.ChartAreas.Clear();
                chart.ChartAreas.Add(new ChartArea("MainArea"));

                Series series = new Series("Data");
                series.ChartType = chartType;
                chart.Series.Add(series);

                foreach (DataRow row in dt.Rows)
                {
                    series.Points.AddXY(row[xMember].ToString(), Convert.ToDouble(row[yMember]));
                }

                chart.Titles.Clear();
                chart.Titles.Add(title);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading chart: " + ex.Message);
                con.Close();
            }
        }

        private void LoadYearlyRevenueChart()
        {
            string query = @"
SELECT Year(CheckIn) AS RevenueYear, SUM(TotalCost) AS TotalRevenue
FROM Reservation
GROUP BY Year(CheckIn)
ORDER BY Year(CheckIn)";

            OleDbCommand cmd = new OleDbCommand(query, con);

            con.Open();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            chartYearlyRevenue.Series.Clear();
            chartYearlyRevenue.ChartAreas.Clear();
            chartYearlyRevenue.Titles.Clear();
            chartYearlyRevenue.Legends.Clear();

            chartYearlyRevenue.Width = 550;
            chartYearlyRevenue.Height = 300;

            ChartArea area = new ChartArea("MainArea");
            area.AxisX.Title = "Year";
            area.AxisY.Title = "Revenue (₱)";
            area.AxisX.Interval = 1;
            area.AxisY.LabelStyle.Format = "₱#,##0";
            area.AxisX.MajorGrid.Enabled = false;

            chartYearlyRevenue.ChartAreas.Add(area);

            Series series = new Series("Yearly Revenue")
            {
                ChartType = SeriesChartType.Column,
                IsValueShownAsLabel = true,
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                LabelForeColor = Color.Black,
                ["PointWidth"] = "0.4"
            };

            foreach (DataRow row in dt.Rows)
            {
                int year = Convert.ToInt32(row["RevenueYear"]);
                double revenue = Convert.ToDouble(row["TotalRevenue"]);

                DataPoint point = new DataPoint
                {
                    AxisLabel = year.ToString(),
                    YValues = new double[] { revenue },
                    Color = Color.MediumSeaGreen,
                    ToolTip = $"Year: {year}\nRevenue: ₱{revenue:N2}",
                    Label = $"{revenue:N2}"
                };

                series.Points.Add(point);
            }

            chartYearlyRevenue.Series.Add(series);
            chartYearlyRevenue.Legends.Add(new Legend("Legend"));
        }

    }
}
