﻿namespace FINAL_PROJECT.User_Control
{
    partial class suggestionview
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvSuggestions = new DataGridView();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvSuggestions).BeginInit();
            SuspendLayout();
            // 
            // dgvSuggestions
            // 
            dgvSuggestions.BackgroundColor = Color.White;
            dgvSuggestions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSuggestions.Location = new Point(58, 31);
            dgvSuggestions.Name = "dgvSuggestions";
            dgvSuggestions.Size = new Size(799, 504);
            dgvSuggestions.TabIndex = 2;
            // 
            // button1
            // 
            button1.BackColor = Color.Teal;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Nirmala UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(763, 541);
            button1.Name = "button1";
            button1.Size = new Size(94, 32);
            button1.TabIndex = 1;
            button1.Text = "Delete";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // suggestionview
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(button1);
            Controls.Add(dgvSuggestions);
            Name = "suggestionview";
            Size = new Size(906, 605);
            ((System.ComponentModel.ISupportInitialize)dgvSuggestions).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvSuggestions;
        private Button button1;
    }
}
