﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_PROJECT.User_Control
{
    public partial class suggestionview : UserControl
    {
        // Constructor to initialize the UserControl and load suggestions
        public suggestionview()
        {
            InitializeComponent();
            LoadSuggestions();
        }

        private void LoadSuggestions()
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;";

            using (OleDbConnection con = new OleDbConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM Suggestion";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dgvSuggestions.DataSource = table;


                    dgvSuggestions.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading suggestions: " + ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Ensure that a row is selected
            if (dgvSuggestions.SelectedRows.Count > 0)
            {
                // Get the selected suggestion text (assuming it's in the second column)
                int selectedRowIndex = dgvSuggestions.SelectedRows[0].Index;
                string suggestionText = dgvSuggestions.Rows[selectedRowIndex].Cells["Suggestion"].Value.ToString();

                // Confirm deletion from user
                DialogResult result = MessageBox.Show("Are you sure you want to delete this suggestion?", "Delete Suggestion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    DeleteSuggestion(suggestionText); // Call the delete method with suggestion text
                }
            }
            else
            {
                MessageBox.Show("Please select a suggestion to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteSuggestion(string suggestionText)
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=System Database.accdb;";
            string deleteQuery = "DELETE FROM Suggestion WHERE Suggestion = ?"; // Use the suggestion text to delete

            using (OleDbConnection con = new OleDbConnection(connectionString))
            {
                try
                {
                    con.Open();
                    using (OleDbCommand cmd = new OleDbCommand(deleteQuery, con))
                    {
                        cmd.Parameters.AddWithValue("?", suggestionText); // Add the suggestion text as a parameter

                        cmd.ExecuteNonQuery(); // Execute the query to delete the suggestion
                    }

                    MessageBox.Show("Suggestion deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadSuggestions(); // Reload the suggestions after deletion
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting suggestion: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
